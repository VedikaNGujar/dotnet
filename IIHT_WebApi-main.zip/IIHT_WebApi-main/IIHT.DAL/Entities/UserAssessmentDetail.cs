﻿using IIHT.DAL.Helper;

namespace IIHT.DAL.Entities
{
    public class UserAssessmentDetail
    {
        public long UserAssessmentAttemptQuestionId { get; set; }
        public long QuestionId { get; set; }
        public long LanguageId { get; set; }
        public string Answer { get; set; }
        public string Language { get; set; }
        public double PlagiarismScore { get; set; }
        public string ScanResultJson { get; set; }
        public long UserId { get; set; }
        public string UserName { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string DefaultCode { get; set; }
        public string GitURL { get; set; }
        public string GitRepositoryName { get; set; }
        public string TemplateURL { get; set; }
        public string ScanConfigDetails { get; set; }

    }
}