﻿using IIHT.DAL.Entities;
using IIHT.DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IIHT.DAL.Contracts
{
    public interface IUserAssessmentAttemptQuestionRepository
    {
        public IEnumerable<UserAssessmentDetail>
            GetUserAssessmentAttemptByAssessmentScheduleIdForSFA(long assessmentId);

        public IEnumerable<UserAssessmentDetail>
            GetUserAssessmentAttemptByAssessmentScheduleIdForMFA(long assessmentId);

        public bool
            UpdatePlagiarismScore(long userAssessmentAttemptQuestionId, double plagiarismScore, string scanResult);
    }
}
