﻿using IIHT.DAL.Contracts;
using IIHT.DAL.Entities;
using IIHT.DAL.Models;
using Microsoft.Extensions.Logging;

namespace IIHT.DAL.Repositories
{
    public class UserAssessmentAttemptQuestionRepository : IUserAssessmentAttemptQuestionRepository
    {
        private readonly StageYakshaCoreContext _context;
        private readonly ILogger<UserAssessmentAttemptQuestionRepository> _logger;
        public UserAssessmentAttemptQuestionRepository(StageYakshaCoreContext context,
            ILogger<UserAssessmentAttemptQuestionRepository> logger)
        {
            _context = context;
            _logger = logger;
        }


        /// <summary>
        /// This will return all the single file assessments answers for assessmentScheduleId
        /// </summary>
        /// <param name="assessmentScheduleId"></param>
        /// <param name="questionTypeId"></param>
        /// <returns></returns>
        public IEnumerable<UserAssessmentDetail>
            GetUserAssessmentAttemptByAssessmentScheduleIdForSFA(long assessmentScheduleId)
        {
            _logger.LogInformation("Begin GetUserAssessmentAttemptByAssessmentScheduleIdForSFA");
            try
            {
                var userAssessmentDetails = from uaq in _context.UserAssessmentAttemptQuestions
                                            join que in _context.Questions on uaq.QuestionId equals que.Id
                                            join ql in _context.QuestionLanguages on new { QuestionId = que.Id, LanguageId = uaq.LanguageId.Value } equals new { ql.QuestionId, ql.LanguageId }
                                            join uad in _context.UserAssessmentAttemptDetails on uaq.UserAssessmentAttemptId equals uad.Id
                                            join uam in _context.UserAssessmentMappings on uad.UserAssessmentMappingId equals uam.Id
                                            join ass in _context.AssessmentSchedules on uam.AssessmentScheduleId equals ass.Id
                                            join u in _context.Users on uaq.UserId equals u.Id
                                            join cl in _context.CompilerLanguages on uaq.LanguageId equals cl.Id
                                            where uaq.IsCodeSubmitted == true && ass.Id == @assessmentScheduleId && que.QuestionTypeId == (int)QuestionTypes.SingleFileAssessment
                                            select new UserAssessmentDetail()
                                            {
                                                UserAssessmentAttemptQuestionId = uaq.Id,
                                                Name = u.Name,
                                                Surname = u.Surname,
                                                UserId = u.Id,
                                                UserName = u.UserName,
                                                Answer = uaq.Answer,
                                                Language = cl.Language,
                                                QuestionId = que.Id,
                                                LanguageId = cl.Id,
                                                DefaultCode = ql.DefaultCode
                                            };
                return userAssessmentDetails;

            }
            catch (Exception ex)
            {
                _logger.LogError($"GetUserAssessmentAttemptByAssessmentScheduleIdForSFA: {ex.Message}");
            }
            _logger.LogInformation("End GetUserAssessmentAttemptByAssessmentScheduleIdForSFA");
            return null;


        }

        public IEnumerable<UserAssessmentDetail>
            GetUserAssessmentAttemptByAssessmentScheduleIdForMFA(long assessmentScheduleId)
        {
            _logger.LogInformation("Begin GetUserAssessmentAttemptByAssessmentScheduleIdForMFA");

            try
            {
                var userAssessmentDetails = from uaq in _context.UserAssessmentAttemptQuestions
                                            join que in _context.Questions on uaq.QuestionId equals que.Id
                                            join sed in _context.StackEnvironmentDetails on que.Id equals sed.QuestionId
                                            join sl in _context.SupportedLanguages on sed.LanguageId equals sl.Id
                                            join uad in _context.UserAssessmentAttemptDetails on uaq.UserAssessmentAttemptId equals uad.Id
                                            join uam in _context.UserAssessmentMappings on uad.UserAssessmentMappingId equals uam.Id
                                            join ass in _context.AssessmentSchedules on uam.AssessmentScheduleId equals ass.Id
                                            join u in _context.Users on uaq.UserId equals u.Id
                                            where ass.Id == @assessmentScheduleId && que.QuestionTypeId == (int)QuestionTypes.MultipleFileAssessment
                                            select new UserAssessmentDetail()
                                            {
                                                UserAssessmentAttemptQuestionId = uaq.Id,
                                                Name = u.Name,
                                                Surname = u.Surname,
                                                UserId = u.Id,
                                                UserName = u.UserName,
                                                Answer = uaq.Answer,
                                                GitURL = uaq.RemoteCodeBaseUrl,
                                                GitRepositoryName = uaq.RepositoryName,
                                                QuestionId = que.Id,
                                                LanguageId = sl.Id,
                                                TemplateURL = sed.GitTemplateUrl,
                                                //ScanConfigDetails = $"<scanConfig>\r\n\t<excludeFolders>\r\n\t\t<excludeFolder>.git</excludeFolder>\r\n\t    <excludeFolder>E-Loan\\.vs</excludeFolder>\r\n        <excludeFolder>E-Loan\\bin</excludeFolder>\r\n\t\t<excludeFolder>E-Loan\\obj</excludeFolder>\t\t\r\n\t\t<excludeFolder>E-Loan\\Properties</excludeFolder>\r\n\t\t<excludeFolder>E-Loan.BusinessLayer\\.vs</excludeFolder>\r\n        <excludeFolder>E-Loan.BusinessLayer\\bin</excludeFolder>\r\n\t\t<excludeFolder>E-Loan.BusinessLayer\\obj</excludeFolder>\t\t\r\n\t\t<excludeFolder>E-Loan.BusinessLayer\\Properties</excludeFolder>\r\n\t\t\r\n\t\t<excludeFolder>E-Loan.DataLayer\\.vs</excludeFolder>\r\n        <excludeFolder>E-Loan.DataLayer\\bin</excludeFolder>\r\n\t\t<excludeFolder>E-Loan.DataLayer\\obj</excludeFolder>\t\t\r\n\t\t<excludeFolder>E-Loan.DataLayer\\Properties</excludeFolder>\r\n\t\t\r\n\t\t<excludeFolder>E-Loan.Entities\\.vs</excludeFolder>\r\n        <excludeFolder>E-Loan.Entities\\bin</excludeFolder>\r\n\t\t<excludeFolder>E-Loan.Entities\\obj</excludeFolder>\t\t\r\n\t\t<excludeFolder>E-Loan.Entities\\Properties</excludeFolder>\r\n\t\t\r\n\t\t<excludeFolder>E-Loan.Tests\\.vs</excludeFolder>\r\n        <excludeFolder>E-Loan.Tests\\bin</excludeFolder>\r\n\t\t<excludeFolder>E-Loan.Tests\\obj</excludeFolder>\t\t\r\n\t\t<excludeFolder>E-Loan.Tests\\Properties</excludeFolder>\r\n\t</excludeFolders>\r\n    <excludeFiles>\r\n        <excludeFile>E-Loan\\appsettings.Development.json</excludeFile>\r\n        <excludeFile>E-Loan\\appsettings.json</excludeFile>\r\n        <excludeFile>E-Loan\\E-Loan.csproj</excludeFile>\r\n        <excludeFile>E-Loan\\E-Loan.csproj.user</excludeFile>\r\n        <excludeFile>E-Loan\\E-Loan.sln</excludeFile>\r\n        <excludeFile>E-Loan\\Program.cs</excludeFile>\r\n\t\t<excludeFile>E-Loan\\Startup.cs</excludeFile>\r\n\t\t<excludeFile>E-Loan\\WeatherForecast.cs</excludeFile>\r\n\t\t\r\n\t\t<excludeFile>E-Loan.BusinessLayer\\E-Loan.BusinessLayer.csproj</excludeFile>\r\n        <excludeFile>E-Loan.BusinessLayer\\E-Loan.BusinessLayer.csproj.user</excludeFile>\r\n\t\t\r\n\t\t<excludeFile>E-Loan.DataLayer\\E-Loan.DataLayer.csproj</excludeFile>\r\n\t\t<excludeFile>E-Loan.Entities\\E-Loan.Entities.csproj</excludeFile>\r\n\t\t<excludeFile>E-Loan.Tests\\E-Loan.Tests.csproj</excludeFile>\r\n    </excludeFiles>\r\n\t\r\n</scanConfig>"
                                                ScanConfigDetails = sed.ScanConfigXML
                                            };
                return userAssessmentDetails;

            }
            catch (Exception ex)
            {
                _logger.LogError($"GetUserAssessmentAttemptByAssessmentScheduleIdForMFA: {ex.Message}");

            }

            _logger.LogInformation("End GetUserAssessmentAttemptByAssessmentScheduleIdForMFA");
            return null;

        }

        public bool UpdatePlagiarismScore(long userAssessmentAttemptQuestionId, double plagiarismScore, string scanResult)
        {
            _logger.LogInformation("Begin UpdatePlagiarismScore");

            try
            {
                var userAssessmentAttemptQuestion = _context.UserAssessmentAttemptQuestions
                    .FirstOrDefault(x => x.Id == userAssessmentAttemptQuestionId);
                if (userAssessmentAttemptQuestion != null)
                {
                    userAssessmentAttemptQuestion.PlagiarismScore = plagiarismScore;
                    userAssessmentAttemptQuestion.ScanResultJson = scanResult;
                    _context.Update<UserAssessmentAttemptQuestion>(userAssessmentAttemptQuestion);
                    _context.SaveChanges();
                    return true;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"UpdatePlagiarismScore : {ex.Message}");
            }
            _logger.LogInformation("End UpdatePlagiarismScore");
            return false;
        }
    }
}
