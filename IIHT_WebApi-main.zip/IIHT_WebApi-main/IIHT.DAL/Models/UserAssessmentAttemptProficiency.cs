﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class UserAssessmentAttemptProficiency
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public long UserAssessmentAttemptDetailId { get; set; }

    public long AssessmentSectionId { get; set; }

    public long AssessmentSectionSkillId { get; set; }

    public long ProficiencyId { get; set; }

    public int AttemptNumber { get; set; }

    public int Status { get; set; }

    public decimal ScorePercentage { get; set; }

    public virtual UserAssessmentAttemptDetail UserAssessmentAttemptDetail { get; set; } = null!;
}
