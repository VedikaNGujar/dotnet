﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class StackEnvironmentDetailsImport
{
    public long Id { get; set; }

    public long JobMetadataId { get; set; }

    public string? QuestionIdNumber { get; set; }

    public string? InstructionDocumentUrl { get; set; }

    public string? Sku { get; set; }

    public string? ContainerImageUrl { get; set; }

    public string? GitTemplateUrl { get; set; }

    public int StackLanguageId { get; set; }

    public string? TestCaseDetails { get; set; }

    public int Score { get; set; }
}
