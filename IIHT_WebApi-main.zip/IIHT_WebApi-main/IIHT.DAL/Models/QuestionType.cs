﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class QuestionType
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public string? Name { get; set; }

    public string? Config { get; set; }

    public long? ParentQuestionTypeId { get; set; }

    public virtual ICollection<AssessmentSectionSkillMetadatum> AssessmentSectionSkillMetadata { get; } = new List<AssessmentSectionSkillMetadatum>();

    public virtual ICollection<ProficiencyMetaDatum> ProficiencyMetaData { get; } = new List<ProficiencyMetaDatum>();

    public virtual ICollection<Question> Questions { get; } = new List<Question>();
}
