﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class TenantQuestions20221031
{
    public long Id { get; set; }

    public string? Questiontext { get; set; }

    public string? Keyword { get; set; }

    public long QuestionTypeId { get; set; }

    public long ParentQuestionTypeId { get; set; }

    public string? Choices { get; set; }

    public string? Answers { get; set; }

    public long CategoryId { get; set; }

    public long ProficiencyId { get; set; }

    public string? Config { get; set; }

    public long Mark { get; set; }

    public long Duration { get; set; }

    public long Weight { get; set; }

    public long SkillId { get; set; }

    public long? SubSkillId { get; set; }

    public long? SubSkill2Id { get; set; }
}
