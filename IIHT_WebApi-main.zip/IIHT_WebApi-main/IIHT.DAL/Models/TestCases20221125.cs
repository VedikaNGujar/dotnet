﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class TestCases20221125
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public long QuestionId { get; set; }

    public string? TestCaseTitle { get; set; }

    public string? StandardInput { get; set; }

    public string? ExpectedOutput { get; set; }

    public long? MaxCpuTime { get; set; }

    public long? MaxMemoryPermitted { get; set; }

    public decimal? Score { get; set; }

    public string? ElementId { get; set; }

    public string? ElementName { get; set; }
}
