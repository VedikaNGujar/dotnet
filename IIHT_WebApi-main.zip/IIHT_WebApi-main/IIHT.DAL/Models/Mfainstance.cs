﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class Mfainstance
{
    public string? AppservicePlan { get; set; }

    public string? ResourceGroupName { get; set; }

    public int? AppservicePlanPriority { get; set; }

    public int? ResourceGroupPriority { get; set; }

    public int? UsageCount { get; set; }

    public int? MaxUsageCount { get; set; }
}
