﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class TestCaseImport
{
    public long Id { get; set; }

    public long JobMetadataId { get; set; }

    public string? QuestionIdNumber { get; set; }

    public string? TestCaseTitle { get; set; }

    public string? StandardInput { get; set; }

    public string? ExpectedOutput { get; set; }

    public long? MaxCpuTime { get; set; }

    public long? MaxMemoryPermitted { get; set; }

    public string? Score { get; set; }
}
