﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace IIHT.DAL.Models;

public partial class StageYakshaCoreContext : DbContext
{
    private readonly IConfiguration _configuration;

    public StageYakshaCoreContext(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public StageYakshaCoreContext(DbContextOptions<StageYakshaCoreContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Assessment> Assessments { get; set; }

    public virtual DbSet<AssessmentCategories1705> AssessmentCategories1705s { get; set; }

    public virtual DbSet<AssessmentCategory> AssessmentCategories { get; set; }

    public virtual DbSet<AssessmentDetail> AssessmentDetails { get; set; }

    public virtual DbSet<AssessmentReviewer> AssessmentReviewers { get; set; }

    public virtual DbSet<AssessmentSchedule> AssessmentSchedules { get; set; }

    public virtual DbSet<AssessmentScheduleCustomField> AssessmentScheduleCustomFields { get; set; }

    public virtual DbSet<AssessmentScheduleResultShareMode> AssessmentScheduleResultShareModes { get; set; }

    public virtual DbSet<AssessmentScheduleReviewer> AssessmentScheduleReviewers { get; set; }

    public virtual DbSet<AssessmentScheduleSectionsConfig> AssessmentScheduleSectionsConfigs { get; set; }

    public virtual DbSet<AssessmentScheduleTemplateMapping> AssessmentScheduleTemplateMappings { get; set; }

    public virtual DbSet<AssessmentSchedulesBackup> AssessmentSchedulesBackups { get; set; }

    public virtual DbSet<AssessmentSection> AssessmentSections { get; set; }

    public virtual DbSet<AssessmentSectionSkill> AssessmentSectionSkills { get; set; }

    public virtual DbSet<AssessmentSectionSkillMetadataProficiency> AssessmentSectionSkillMetadataProficiencies { get; set; }

    public virtual DbSet<AssessmentSectionSkillMetadatum> AssessmentSectionSkillMetadata { get; set; }

    public virtual DbSet<AssessmentSectionSkillQuestion> AssessmentSectionSkillQuestions { get; set; }

    public virtual DbSet<BackgroundJobDefinition> BackgroundJobDefinitions { get; set; }

    public virtual DbSet<CatalogAssessment> CatalogAssessments { get; set; }

    public virtual DbSet<CatalogAssessmentSchedule> CatalogAssessmentSchedules { get; set; }

    public virtual DbSet<CatalogDefinition> CatalogDefinitions { get; set; }

    public virtual DbSet<Category> Categories { get; set; }

    public virtual DbSet<CategoryListBasedOnProducti> CategoryListBasedOnProductis { get; set; }

    public virtual DbSet<CategorySkillMapping> CategorySkillMappings { get; set; }

    public virtual DbSet<CategorySkillMappings1705> CategorySkillMappings1705s { get; set; }

    public virtual DbSet<CategoryUpdate> CategoryUpdates { get; set; }

    public virtual DbSet<CodeAnalysisMetric> CodeAnalysisMetrics { get; set; }

    public virtual DbSet<CodeAnalysisMetricsBkp> CodeAnalysisMetricsBkps { get; set; }

    public virtual DbSet<CodeBaseTokenProvider> CodeBaseTokenProviders { get; set; }

    public virtual DbSet<CompilerLanguage> CompilerLanguages { get; set; }

    public virtual DbSet<DefaultQuestions20221031> DefaultQuestions20221031s { get; set; }

    public virtual DbSet<DefaultQuestions20221125> DefaultQuestions20221125s { get; set; }

    public virtual DbSet<EmailConfiguration> EmailConfigurations { get; set; }

    public virtual DbSet<EmailTemplate> EmailTemplates { get; set; }

    public virtual DbSet<ExistingProctoringReportFinal> ExistingProctoringReportFinals { get; set; }

    public virtual DbSet<FillteredQuestions20221031> FillteredQuestions20221031s { get; set; }

    public virtual DbSet<FillteredQuestions20221125> FillteredQuestions20221125s { get; set; }

    public virtual DbSet<JobMetadatum> JobMetadata { get; set; }

    public virtual DbSet<Mfainstance> Mfainstances { get; set; }

    public virtual DbSet<Permission> Permissions { get; set; }

    public virtual DbSet<Proficiency> Proficiencies { get; set; }

    public virtual DbSet<ProficiencyMetaDatum> ProficiencyMetaData { get; set; }

    public virtual DbSet<Question> Questions { get; set; }

    public virtual DbSet<QuestionBank> QuestionBanks { get; set; }

    public virtual DbSet<QuestionBankItem> QuestionBankItems { get; set; }

    public virtual DbSet<QuestionBankSkill> QuestionBankSkills { get; set; }

    public virtual DbSet<QuestionBankSkills20221031> QuestionBankSkills20221031s { get; set; }

    public virtual DbSet<QuestionBankSkills20221125> QuestionBankSkills20221125s { get; set; }

    public virtual DbSet<QuestionHint> QuestionHints { get; set; }

    public virtual DbSet<QuestionHintImport> QuestionHintImports { get; set; }

    public virtual DbSet<QuestionHints20221031> QuestionHints20221031s { get; set; }

    public virtual DbSet<QuestionHints20221125> QuestionHints20221125s { get; set; }

    public virtual DbSet<QuestionImport> QuestionImports { get; set; }

    public virtual DbSet<QuestionLanguage> QuestionLanguages { get; set; }

    public virtual DbSet<QuestionLanguageImport> QuestionLanguageImports { get; set; }

    public virtual DbSet<QuestionLanguages20221031> QuestionLanguages20221031s { get; set; }

    public virtual DbSet<QuestionLanguages20221125> QuestionLanguages20221125s { get; set; }

    public virtual DbSet<QuestionSkillMapping> QuestionSkillMappings { get; set; }

    public virtual DbSet<QuestionSkillMapping20221031> QuestionSkillMapping20221031s { get; set; }

    public virtual DbSet<QuestionSkillMapping20221125> QuestionSkillMapping20221125s { get; set; }

    public virtual DbSet<QuestionType> QuestionTypes { get; set; }

    public virtual DbSet<Questions1705> Questions1705s { get; set; }

    public virtual DbSet<Questions20221031> Questions20221031s { get; set; }

    public virtual DbSet<Questions20221125> Questions20221125s { get; set; }

    public virtual DbSet<ReportDatum> ReportData { get; set; }

    public virtual DbSet<ResourceProvisioningAudit> ResourceProvisioningAudits { get; set; }

    public virtual DbSet<ReviewComment> ReviewComments { get; set; }

    public virtual DbSet<Role> Roles { get; set; }

    public virtual DbSet<RolePermission> RolePermissions { get; set; }

    public virtual DbSet<ScheduleSectionSkillMetadatum> ScheduleSectionSkillMetadata { get; set; }

    public virtual DbSet<Sheet1> Sheet1s { get; set; }

    public virtual DbSet<Skill> Skills { get; set; }

    public virtual DbSet<Skill4> Skill4s { get; set; }

    public virtual DbSet<SkillListBasedOnProduction> SkillListBasedOnProductions { get; set; }

    public virtual DbSet<Skills2> Skills2s { get; set; }

    public virtual DbSet<Skills2103> Skills2103s { get; set; }

    public virtual DbSet<StackEnvironmentAudit> StackEnvironmentAudits { get; set; }

    public virtual DbSet<StackEnvironmentAuditsBkp> StackEnvironmentAuditsBkps { get; set; }

    public virtual DbSet<StackEnvironmentDetail> StackEnvironmentDetails { get; set; }

    public virtual DbSet<StackEnvironmentDetails20221031> StackEnvironmentDetails20221031s { get; set; }

    public virtual DbSet<StackEnvironmentDetails20221125> StackEnvironmentDetails20221125s { get; set; }

    public virtual DbSet<StackEnvironmentDetailsImport> StackEnvironmentDetailsImports { get; set; }

    public virtual DbSet<StackEnvironmentProvider> StackEnvironmentProviders { get; set; }

    public virtual DbSet<StackTemplateType> StackTemplateTypes { get; set; }

    public virtual DbSet<StackTestCaseEvaluationResult> StackTestCaseEvaluationResults { get; set; }

    public virtual DbSet<StackTestCaseEvaluationResultsBkp> StackTestCaseEvaluationResultsBkps { get; set; }

    public virtual DbSet<StackTestCaseResult> StackTestCaseResults { get; set; }

    public virtual DbSet<StackTestCaseResultsBkp> StackTestCaseResultsBkps { get; set; }

    public virtual DbSet<SupportedLanguage> SupportedLanguages { get; set; }

    public virtual DbSet<SupportedRegion> SupportedRegions { get; set; }

    public virtual DbSet<Tenant> Tenants { get; set; }

    public virtual DbSet<TenantAssessmentReview> TenantAssessmentReviews { get; set; }

    public virtual DbSet<TenantCatalog> TenantCatalogs { get; set; }

    public virtual DbSet<TenantConfiguration> TenantConfigurations { get; set; }

    public virtual DbSet<TenantManager> TenantManagers { get; set; }

    public virtual DbSet<TenantQuestionBank> TenantQuestionBanks { get; set; }

    public virtual DbSet<TenantQuestions20221031> TenantQuestions20221031s { get; set; }

    public virtual DbSet<TenantQuestions20221125> TenantQuestions20221125s { get; set; }

    public virtual DbSet<TestCase> TestCases { get; set; }

    public virtual DbSet<TestCaseConstraint> TestCaseConstraints { get; set; }

    public virtual DbSet<TestCaseImport> TestCaseImports { get; set; }

    public virtual DbSet<TestCases20221031> TestCases20221031s { get; set; }

    public virtual DbSet<TestCases20221125> TestCases20221125s { get; set; }

    public virtual DbSet<UpdatedMessage> UpdatedMessages { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<UserAssessmentAttemptDetail> UserAssessmentAttemptDetails { get; set; }

    public virtual DbSet<UserAssessmentAttemptDetails2403> UserAssessmentAttemptDetails2403s { get; set; }

    public virtual DbSet<UserAssessmentAttemptProficiency> UserAssessmentAttemptProficiencies { get; set; }

    public virtual DbSet<UserAssessmentAttemptQuestion> UserAssessmentAttemptQuestions { get; set; }

    public virtual DbSet<UserAssessmentAttemptSection> UserAssessmentAttemptSections { get; set; }

    public virtual DbSet<UserAssessmentCodingBasedResult> UserAssessmentCodingBasedResults { get; set; }

    public virtual DbSet<UserAssessmentMapping> UserAssessmentMappings { get; set; }

    public virtual DbSet<UserAssessmentScheduleInvite> UserAssessmentScheduleInvites { get; set; }

    public virtual DbSet<UserRole> UserRoles { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
          => optionsBuilder.UseSqlServer(_configuration.GetConnectionString("SqlConnection"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Assessment>(entity =>
        {
            entity.ToTable("Assessments", "Yaksha.Core");
        });

        modelBuilder.Entity<AssessmentCategories1705>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("AssessmentCategories_1705", "Yaksha.Core");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<AssessmentCategory>(entity =>
        {
            entity.ToTable("AssessmentCategories", "Yaksha.Core");

            entity.HasIndex(e => e.AssessmentId, "IX_AssessmentCategories_AssessmentId");

            entity.HasIndex(e => e.CategoryId, "IX_AssessmentCategories_CategoryId");

            entity.HasOne(d => d.Assessment).WithMany(p => p.AssessmentCategories).HasForeignKey(d => d.AssessmentId);

            entity.HasOne(d => d.Category).WithMany(p => p.AssessmentCategories).HasForeignKey(d => d.CategoryId);
        });

        modelBuilder.Entity<AssessmentDetail>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("AssessmentDetails$");

            entity.Property(e => e.YakshaTestNames).HasMaxLength(255);
        });

        modelBuilder.Entity<AssessmentReviewer>(entity =>
        {
            entity.ToTable("AssessmentReviewers", "Yaksha.Core");

            entity.HasIndex(e => e.TenantAssessmentReviewId, "IX_AssessmentReviewers_TenantAssessmentReviewId");

            entity.HasOne(d => d.TenantAssessmentReview).WithMany(p => p.AssessmentReviewers).HasForeignKey(d => d.TenantAssessmentReviewId);
        });

        modelBuilder.Entity<AssessmentSchedule>(entity =>
        {
            entity.ToTable("AssessmentSchedules", "Yaksha.Core");

            entity.HasIndex(e => e.AssessmentId, "IX_AssessmentSchedules_AssessmentId");

            entity.HasOne(d => d.Assessment).WithMany(p => p.AssessmentSchedules).HasForeignKey(d => d.AssessmentId);
        });

        modelBuilder.Entity<AssessmentScheduleCustomField>(entity =>
        {
            entity.ToTable("AssessmentScheduleCustomField", "Yaksha.Core");

            entity.HasIndex(e => e.AssessmentScheduleId, "IX_AssessmentScheduleCustomField_AssessmentScheduleId");

            entity.HasOne(d => d.AssessmentSchedule).WithMany(p => p.AssessmentScheduleCustomFields).HasForeignKey(d => d.AssessmentScheduleId);
        });

        modelBuilder.Entity<AssessmentScheduleResultShareMode>(entity =>
        {
            entity.ToTable("AssessmentScheduleResultShareModes", "Yaksha.Core");

            entity.HasIndex(e => e.AssessmentScheduleId, "IX_AssessmentScheduleResultShareModes_AssessmentScheduleId");

            entity.HasOne(d => d.AssessmentSchedule).WithMany(p => p.AssessmentScheduleResultShareModes).HasForeignKey(d => d.AssessmentScheduleId);
        });

        modelBuilder.Entity<AssessmentScheduleReviewer>(entity =>
        {
            entity.ToTable("AssessmentScheduleReviewers", "Yaksha.Core");

            entity.HasIndex(e => e.AssessmentScheduleId, "IX_AssessmentScheduleReviewers_AssessmentScheduleId");

            entity.HasOne(d => d.AssessmentSchedule).WithMany(p => p.AssessmentScheduleReviewers).HasForeignKey(d => d.AssessmentScheduleId);
        });

        modelBuilder.Entity<AssessmentScheduleSectionsConfig>(entity =>
        {
            entity.ToTable("AssessmentScheduleSectionsConfig", "Yaksha.Core");

            entity.HasIndex(e => e.AssessmentScheduleId, "IX_AssessmentScheduleSectionsConfig_AssessmentScheduleId");

            entity.HasOne(d => d.AssessmentSchedule).WithMany(p => p.AssessmentScheduleSectionsConfigs).HasForeignKey(d => d.AssessmentScheduleId);
        });

        modelBuilder.Entity<AssessmentScheduleTemplateMapping>(entity =>
        {
            entity.ToTable("AssessmentScheduleTemplateMappings", "Yaksha.Core");

            entity.HasIndex(e => e.AssessmentScheduleId, "IX_AssessmentScheduleTemplateMappings_AssessmentScheduleId");

            entity.HasOne(d => d.AssessmentSchedule).WithMany(p => p.AssessmentScheduleTemplateMappings).HasForeignKey(d => d.AssessmentScheduleId);
        });

        modelBuilder.Entity<AssessmentSchedulesBackup>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("AssessmentSchedules_backup", "Yaksha.Core");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<AssessmentSection>(entity =>
        {
            entity.ToTable("AssessmentSections", "Yaksha.Core");

            entity.HasIndex(e => e.AssessmentId, "IX_AssessmentSections_AssessmentId");

            entity.HasOne(d => d.Assessment).WithMany(p => p.AssessmentSections).HasForeignKey(d => d.AssessmentId);
        });

        modelBuilder.Entity<AssessmentSectionSkill>(entity =>
        {
            entity.ToTable("AssessmentSectionSkills", "Yaksha.Core");

            entity.HasIndex(e => e.AssessmentSectionId, "IX_AssessmentSectionSkills_AssessmentSectionId");

            entity.HasIndex(e => e.SkillId, "IX_AssessmentSectionSkills_SkillId");

            entity.HasOne(d => d.AssessmentSection).WithMany(p => p.AssessmentSectionSkills).HasForeignKey(d => d.AssessmentSectionId);

            entity.HasOne(d => d.Skill).WithMany(p => p.AssessmentSectionSkills).HasForeignKey(d => d.SkillId);
        });

        modelBuilder.Entity<AssessmentSectionSkillMetadataProficiency>(entity =>
        {
            entity.ToTable("AssessmentSectionSkillMetadataProficiencies", "Yaksha.Core");

            entity.HasIndex(e => e.AssessmentSectionSkillMetadataId, "IX_AssessmentSectionSkillMetadataProficiencies_AssessmentSectionSkillMetadataId");

            entity.HasIndex(e => e.ProficiencyId, "IX_AssessmentSectionSkillMetadataProficiencies_ProficiencyId");

            entity.HasOne(d => d.AssessmentSectionSkillMetadata).WithMany(p => p.AssessmentSectionSkillMetadataProficiencies).HasForeignKey(d => d.AssessmentSectionSkillMetadataId);

            entity.HasOne(d => d.Proficiency).WithMany(p => p.AssessmentSectionSkillMetadataProficiencies).HasForeignKey(d => d.ProficiencyId);
        });

        modelBuilder.Entity<AssessmentSectionSkillMetadatum>(entity =>
        {
            entity.ToTable("AssessmentSectionSkillMetadata", "Yaksha.Core");

            entity.HasIndex(e => e.AssessmentSectionSkillId, "IX_AssessmentSectionSkillMetadata_AssessmentSectionSkillId");

            entity.HasIndex(e => e.ParentQuestionTypeId, "IX_AssessmentSectionSkillMetadata_ParentQuestionTypeId");

            entity.HasOne(d => d.AssessmentSectionSkill).WithMany(p => p.AssessmentSectionSkillMetadata).HasForeignKey(d => d.AssessmentSectionSkillId);

            entity.HasOne(d => d.ParentQuestionType).WithMany(p => p.AssessmentSectionSkillMetadata).HasForeignKey(d => d.ParentQuestionTypeId);
        });

        modelBuilder.Entity<AssessmentSectionSkillQuestion>(entity =>
        {
            entity.ToTable("AssessmentSectionSkillQuestions", "Yaksha.Core");

            entity.HasIndex(e => e.AssessmentSectionSkillId, "IX_AssessmentSectionSkillQuestions_AssessmentSectionSkillId");

            entity.HasIndex(e => e.QuestionId, "IX_AssessmentSectionSkillQuestions_QuestionId");

            entity.HasOne(d => d.AssessmentSectionSkill).WithMany(p => p.AssessmentSectionSkillQuestions).HasForeignKey(d => d.AssessmentSectionSkillId);

            entity.HasOne(d => d.Question).WithMany(p => p.AssessmentSectionSkillQuestions).HasForeignKey(d => d.QuestionId);
        });

        modelBuilder.Entity<BackgroundJobDefinition>(entity =>
        {
            entity.ToTable("BackgroundJobDefinitions", "Yaksha.Core");
        });

        modelBuilder.Entity<CatalogAssessment>(entity =>
        {
            entity.ToTable("CatalogAssessments", "Yaksha.Core");

            entity.HasIndex(e => e.AssessmentId, "IX_CatalogAssessments_AssessmentId");

            entity.HasIndex(e => e.CatalogId, "IX_CatalogAssessments_CatalogId");

            entity.HasOne(d => d.Assessment).WithMany(p => p.CatalogAssessments).HasForeignKey(d => d.AssessmentId);

            entity.HasOne(d => d.Catalog).WithMany(p => p.CatalogAssessments).HasForeignKey(d => d.CatalogId);
        });

        modelBuilder.Entity<CatalogAssessmentSchedule>(entity =>
        {
            entity.ToTable("CatalogAssessmentSchedules", "Yaksha.Core");

            entity.HasIndex(e => e.AssessmentScheduleId, "IX_CatalogAssessmentSchedules_AssessmentScheduleId");

            entity.HasIndex(e => e.CatalogId, "IX_CatalogAssessmentSchedules_CatalogId");

            entity.HasOne(d => d.AssessmentSchedule).WithMany(p => p.CatalogAssessmentSchedules).HasForeignKey(d => d.AssessmentScheduleId);

            entity.HasOne(d => d.Catalog).WithMany(p => p.CatalogAssessmentSchedules).HasForeignKey(d => d.CatalogId);
        });

        modelBuilder.Entity<CatalogDefinition>(entity =>
        {
            entity.ToTable("CatalogDefinitions", "Yaksha.Core");
        });

        modelBuilder.Entity<Category>(entity =>
        {
            entity.ToTable("Categories", "Yaksha.Core");

            entity.HasIndex(e => e.ParentCategoryId, "IX_Categories_ParentCategoryId");

            entity.HasOne(d => d.ParentCategory).WithMany(p => p.InverseParentCategory).HasForeignKey(d => d.ParentCategoryId);
        });

        modelBuilder.Entity<CategoryListBasedOnProducti>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("'Category List based on Producti$'");

            entity.Property(e => e.Categorys).HasMaxLength(255);
        });

        modelBuilder.Entity<CategorySkillMapping>(entity =>
        {
            entity.ToTable("CategorySkillMappings", "Yaksha.Core");

            entity.HasIndex(e => e.CategoryId, "IX_CategorySkillMappings_CategoryId");

            entity.HasIndex(e => e.SkillId, "IX_CategorySkillMappings_SkillId");

            entity.HasOne(d => d.Category).WithMany(p => p.CategorySkillMappings).HasForeignKey(d => d.CategoryId);

            entity.HasOne(d => d.Skill).WithMany(p => p.CategorySkillMappings).HasForeignKey(d => d.SkillId);
        });

        modelBuilder.Entity<CategorySkillMappings1705>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("CategorySkillMappings_1705", "Yaksha.Core");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<CategoryUpdate>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("CategoryUpdate$");

            entity.Property(e => e.CategoryName).HasMaxLength(255);
            entity.Property(e => e.NewCategoryName)
                .HasMaxLength(255)
                .HasColumnName("New CategoryName");
        });

        modelBuilder.Entity<CodeAnalysisMetric>(entity =>
        {
            entity.ToTable("CodeAnalysisMetrics", "Yaksha.Stack");
        });

        modelBuilder.Entity<CodeAnalysisMetricsBkp>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("CodeAnalysisMetrics_bkp");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<CodeBaseTokenProvider>(entity =>
        {
            entity.ToTable("CodeBaseTokenProviders", "Yaksha.Stack");
        });

        modelBuilder.Entity<CompilerLanguage>(entity =>
        {
            entity.ToTable("CompilerLanguages", "Yaksha.Coding");
        });

        modelBuilder.Entity<DefaultQuestions20221031>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("defaultQuestions_20221031");

            entity.Property(e => e.Keyword).HasColumnName("keyword");
            entity.Property(e => e.Questiontext).HasColumnName("questiontext");
        });

        modelBuilder.Entity<DefaultQuestions20221125>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("defaultQuestions_20221125");

            entity.Property(e => e.Keyword).HasColumnName("keyword");
            entity.Property(e => e.Questiontext).HasColumnName("questiontext");
        });

        modelBuilder.Entity<EmailConfiguration>(entity =>
        {
            entity.ToTable("EmailConfigurations", "Yaksha.Core");
        });

        modelBuilder.Entity<EmailTemplate>(entity =>
        {
            entity.ToTable("EmailTemplates", "Yaksha.Core");
        });

        modelBuilder.Entity<ExistingProctoringReportFinal>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("ExistingProctoringReport_Final$");

            entity.Property(e => e.ErrorMessage).HasMaxLength(255);
            entity.Property(e => e.EventId).HasMaxLength(255);
            entity.Property(e => e.StudentId).HasMaxLength(255);
        });

        modelBuilder.Entity<FillteredQuestions20221031>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("fillteredQuestions_20221031");

            entity.Property(e => e.Config)
                .HasMaxLength(1)
                .IsUnicode(false);
            entity.Property(e => e.OldId).HasColumnName("old_id");
            entity.Property(e => e.Questionid)
                .HasColumnType("numeric(38, 0)")
                .HasColumnName("questionid");
            entity.Property(e => e.Questiontext).HasColumnName("questiontext");
        });

        modelBuilder.Entity<FillteredQuestions20221125>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("fillteredQuestions_20221125");

            entity.Property(e => e.Config)
                .HasMaxLength(1)
                .IsUnicode(false);
            entity.Property(e => e.OldId).HasColumnName("old_id");
            entity.Property(e => e.Questionid)
                .HasColumnType("numeric(38, 0)")
                .HasColumnName("questionid");
            entity.Property(e => e.Questiontext).HasColumnName("questiontext");
        });

        modelBuilder.Entity<JobMetadatum>(entity =>
        {
            entity.ToTable("JobMetadata", "Yaksha.Core");

            entity.HasIndex(e => e.BackgroundJobDefinitionId, "IX_JobMetadata_BackgroundJobDefinitionId");

            entity.HasOne(d => d.BackgroundJobDefinition).WithMany(p => p.JobMetadata).HasForeignKey(d => d.BackgroundJobDefinitionId);
        });

        modelBuilder.Entity<Mfainstance>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("MFAInstances");
        });

        modelBuilder.Entity<Permission>(entity =>
        {
            entity.ToTable("Permissions", "Yaksha.Core");

            entity.Property(e => e.Component).HasMaxLength(255);
            entity.Property(e => e.ModuleName).HasMaxLength(255);
            entity.Property(e => e.PermissionName).HasMaxLength(255);
        });

        modelBuilder.Entity<Proficiency>(entity =>
        {
            entity.ToTable("Proficiencies", "Yaksha.Core");
        });

        modelBuilder.Entity<ProficiencyMetaDatum>(entity =>
        {
            entity.ToTable("ProficiencyMetaData", "Yaksha.Core");

            entity.HasIndex(e => e.ParentQuestionTypeId, "IX_ProficiencyMetaData_ParentQuestionTypeId");

            entity.HasIndex(e => e.ProficiencyId, "IX_ProficiencyMetaData_ProficiencyId");

            entity.HasOne(d => d.ParentQuestionType).WithMany(p => p.ProficiencyMetaData).HasForeignKey(d => d.ParentQuestionTypeId);

            entity.HasOne(d => d.Proficiency).WithMany(p => p.ProficiencyMetaData).HasForeignKey(d => d.ProficiencyId);
        });

        modelBuilder.Entity<Question>(entity =>
        {
            entity.ToTable("Questions", "Yaksha.Core");

            entity.HasIndex(e => e.CategoryId, "IX_Questions_CategoryId");

            entity.HasIndex(e => e.QuestionTypeId, "IX_Questions_QuestionTypeId");

            entity.HasOne(d => d.Category).WithMany(p => p.Questions).HasForeignKey(d => d.CategoryId);

            entity.HasOne(d => d.QuestionType).WithMany(p => p.Questions).HasForeignKey(d => d.QuestionTypeId);
        });

        modelBuilder.Entity<QuestionBank>(entity =>
        {
            entity.ToTable("QuestionBanks", "Yaksha.Core");
        });

        modelBuilder.Entity<QuestionBankItem>(entity =>
        {
            entity.ToTable("QuestionBankItems", "Yaksha.Core");

            entity.HasIndex(e => e.QuestionBankId, "IX_QuestionBankItems_QuestionBankId");

            entity.HasIndex(e => e.QuestionId, "IX_QuestionBankItems_QuestionId");

            entity.HasOne(d => d.QuestionBank).WithMany(p => p.QuestionBankItems).HasForeignKey(d => d.QuestionBankId);

            entity.HasOne(d => d.Question).WithMany(p => p.QuestionBankItems).HasForeignKey(d => d.QuestionId);
        });

        modelBuilder.Entity<QuestionBankSkill>(entity =>
        {
            entity.ToTable("QuestionBankSkills", "Yaksha.Core");

            entity.HasIndex(e => e.QuestionBankId, "IX_QuestionBankSkills_QuestionBankId");

            entity.HasIndex(e => e.SkillId, "IX_QuestionBankSkills_SkillId");

            entity.HasOne(d => d.QuestionBank).WithMany(p => p.QuestionBankSkills).HasForeignKey(d => d.QuestionBankId);

            entity.HasOne(d => d.Skill).WithMany(p => p.QuestionBankSkills).HasForeignKey(d => d.SkillId);
        });

        modelBuilder.Entity<QuestionBankSkills20221031>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("QuestionBankSkills_20221031", "Yaksha.Core");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<QuestionBankSkills20221125>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("QuestionBankSkills_20221125", "Yaksha.Core");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<QuestionHint>(entity =>
        {
            entity.ToTable("QuestionHints", "Yaksha.Core");

            entity.HasIndex(e => e.QuestionId, "IX_QuestionHints_QuestionId");

            entity.HasOne(d => d.Question).WithMany(p => p.QuestionHints).HasForeignKey(d => d.QuestionId);
        });

        modelBuilder.Entity<QuestionHintImport>(entity =>
        {
            entity.ToTable("QuestionHintImport", "Yaksha.Core");
        });

        modelBuilder.Entity<QuestionHints20221031>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("QuestionHints_20221031", "Yaksha.Core");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<QuestionHints20221125>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("QuestionHints_20221125", "Yaksha.Core");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<QuestionImport>(entity =>
        {
            entity.ToTable("QuestionImport", "Yaksha.Core");

            entity.HasIndex(e => e.JobMetadataId, "IX_QuestionImport_JobMetadataId");

            entity.HasOne(d => d.JobMetadata).WithMany(p => p.QuestionImports).HasForeignKey(d => d.JobMetadataId);
        });

        modelBuilder.Entity<QuestionLanguage>(entity =>
        {
            entity.HasKey(e => new { e.QuestionId, e.LanguageId });

            entity.ToTable("QuestionLanguages", "Yaksha.Core");

            entity.HasOne(d => d.Question).WithMany(p => p.QuestionLanguages).HasForeignKey(d => d.QuestionId);
        });

        modelBuilder.Entity<QuestionLanguageImport>(entity =>
        {
            entity.ToTable("QuestionLanguageImport", "Yaksha.Core");
        });

        modelBuilder.Entity<QuestionLanguages20221031>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("QuestionLanguages_20221031", "Yaksha.Core");
        });

        modelBuilder.Entity<QuestionLanguages20221125>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("QuestionLanguages_20221125", "Yaksha.Core");
        });

        modelBuilder.Entity<QuestionSkillMapping>(entity =>
        {
            entity.ToTable("QuestionSkillMapping", "Yaksha.Core");

            entity.HasIndex(e => e.QuestionId, "IX_QuestionSkillMapping_QuestionId");

            entity.HasIndex(e => e.SkillId, "IX_QuestionSkillMapping_SkillId");

            entity.HasIndex(e => e.SubSkill2Id, "IX_QuestionSkillMapping_SubSkill2Id");

            entity.HasIndex(e => e.SubSkillId, "IX_QuestionSkillMapping_SubSkillId");

            entity.HasOne(d => d.Question).WithMany(p => p.QuestionSkillMappings).HasForeignKey(d => d.QuestionId);

            entity.HasOne(d => d.Skill).WithMany(p => p.QuestionSkillMappingSkills).HasForeignKey(d => d.SkillId);

            entity.HasOne(d => d.SubSkill2).WithMany(p => p.QuestionSkillMappingSubSkill2s).HasForeignKey(d => d.SubSkill2Id);

            entity.HasOne(d => d.SubSkill).WithMany(p => p.QuestionSkillMappingSubSkills).HasForeignKey(d => d.SubSkillId);
        });

        modelBuilder.Entity<QuestionSkillMapping20221031>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("QuestionSkillMapping_20221031", "Yaksha.Core");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<QuestionSkillMapping20221125>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("QuestionSkillMapping_20221125", "Yaksha.Core");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<QuestionType>(entity =>
        {
            entity.ToTable("QuestionTypes", "Yaksha.Core");
        });

        modelBuilder.Entity<Questions1705>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Questions_1705", "Yaksha.Core");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<Questions20221031>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Questions_20221031", "Yaksha.Core");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<Questions20221125>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Questions_20221125", "Yaksha.Core");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<ReportDatum>(entity =>
        {
            entity.HasNoKey();

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
            entity.Property(e => e.ProctoringScore).HasMaxLength(100);
            entity.Property(e => e.SubmissionType).HasMaxLength(100);
            entity.Property(e => e.TimeTaken).HasMaxLength(100);
        });

        modelBuilder.Entity<ResourceProvisioningAudit>(entity =>
        {
            entity.ToTable("ResourceProvisioningAudits", "Yaksha.Stack");

            entity.HasIndex(e => e.RegionId, "IX_ResourceProvisioningAudits_RegionId");

            entity.HasOne(d => d.Region).WithMany(p => p.ResourceProvisioningAudits).HasForeignKey(d => d.RegionId);
        });

        modelBuilder.Entity<ReviewComment>(entity =>
        {
            entity.ToTable("ReviewComments", "Yaksha.Core");

            entity.HasIndex(e => e.AssessmentReviewerId, "IX_ReviewComments_AssessmentReviewerId");

            entity.HasOne(d => d.AssessmentReviewer).WithMany(p => p.ReviewComments).HasForeignKey(d => d.AssessmentReviewerId);
        });

        modelBuilder.Entity<Role>(entity =>
        {
            entity.ToTable("Roles", "Yaksha.Core");

            entity.Property(e => e.RoleName).HasMaxLength(255);
            entity.Property(e => e.StandardRoleName).HasMaxLength(50);
        });

        modelBuilder.Entity<RolePermission>(entity =>
        {
            entity.ToTable("RolePermissions", "Yaksha.Core");

            entity.HasIndex(e => e.PermissionId, "IX_RolePermissions_PermissionId");

            entity.HasIndex(e => e.RoleId, "IX_RolePermissions_RoleId");

            entity.HasOne(d => d.Permission).WithMany(p => p.RolePermissions).HasForeignKey(d => d.PermissionId);

            entity.HasOne(d => d.Role).WithMany(p => p.RolePermissions).HasForeignKey(d => d.RoleId);
        });

        modelBuilder.Entity<ScheduleSectionSkillMetadatum>(entity =>
        {
            entity.ToTable("ScheduleSectionSkillMetadata", "Yaksha.Core");

            entity.HasIndex(e => e.AssessmentScheduleId, "IX_ScheduleSectionSkillMetadata_AssessmentScheduleId");

            entity.HasOne(d => d.AssessmentSchedule).WithMany(p => p.ScheduleSectionSkillMetadata).HasForeignKey(d => d.AssessmentScheduleId);
        });

        modelBuilder.Entity<Sheet1>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Sheet1$");

            entity.Property(e => e.SkillName).HasMaxLength(255);
        });

        modelBuilder.Entity<Skill>(entity =>
        {
            entity.ToTable("Skills", "Yaksha.Core");
        });

        modelBuilder.Entity<Skill4>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Skill4$");

            entity.Property(e => e.SkillName).HasMaxLength(255);
        });

        modelBuilder.Entity<SkillListBasedOnProduction>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("'Skill List based on Production$'");

            entity.Property(e => e.SkillName).HasMaxLength(255);
        });

        modelBuilder.Entity<Skills2>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("skills2$");

            entity.Property(e => e.SkillName).HasMaxLength(255);
        });

        modelBuilder.Entity<Skills2103>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Skills2103$");

            entity.Property(e => e.F2).HasMaxLength(255);
            entity.Property(e => e.Skills).HasMaxLength(255);
        });

        modelBuilder.Entity<StackEnvironmentAudit>(entity =>
        {
            entity.ToTable("StackEnvironmentAudits", "Yaksha.Stack");
        });

        modelBuilder.Entity<StackEnvironmentAuditsBkp>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("StackEnvironmentAudits_bkp");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<StackEnvironmentDetail>(entity =>
        {
            entity.ToTable("StackEnvironmentDetails", "Yaksha.Stack");

            entity.HasIndex(e => e.LanguageId, "IX_StackEnvironmentDetails_LanguageId");

            entity.HasOne(d => d.Language).WithMany(p => p.StackEnvironmentDetails).HasForeignKey(d => d.LanguageId);
        });

        modelBuilder.Entity<StackEnvironmentDetails20221031>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("StackEnvironmentDetails_20221031", "Yaksha.Stack");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<StackEnvironmentDetails20221125>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("StackEnvironmentDetails_20221125", "Yaksha.Stack");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<StackEnvironmentDetailsImport>(entity =>
        {
            entity.ToTable("StackEnvironmentDetailsImport", "Yaksha.Core");
        });

        modelBuilder.Entity<StackEnvironmentProvider>(entity =>
        {
            entity.ToTable("StackEnvironmentProviders", "Yaksha.Stack");

            entity.HasIndex(e => e.LanguageId, "IX_StackEnvironmentProviders_LanguageId");

            entity.Property(e => e.TemplateTypeId).HasDefaultValueSql("(CONVERT([bigint],(0)))");

            entity.HasOne(d => d.Language).WithMany(p => p.StackEnvironmentProviders).HasForeignKey(d => d.LanguageId);
        });

        modelBuilder.Entity<StackTemplateType>(entity =>
        {
            entity.ToTable("StackTemplateTypes", "Yaksha.Stack");
        });

        modelBuilder.Entity<StackTestCaseEvaluationResult>(entity =>
        {
            entity.ToTable("StackTestCaseEvaluationResults", "Yaksha.Stack");
        });

        modelBuilder.Entity<StackTestCaseEvaluationResultsBkp>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("StackTestCaseEvaluationResults_bkp");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<StackTestCaseResult>(entity =>
        {
            entity.ToTable("StackTestCaseResults", "Yaksha.Stack");
        });

        modelBuilder.Entity<StackTestCaseResultsBkp>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("StackTestCaseResults_bkp");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<SupportedLanguage>(entity =>
        {
            entity.ToTable("SupportedLanguages", "Yaksha.Stack");
        });

        modelBuilder.Entity<SupportedRegion>(entity =>
        {
            entity.ToTable("SupportedRegions", "Yaksha.Stack");
        });

        modelBuilder.Entity<Tenant>(entity =>
        {
            entity.ToTable("Tenants", "Yaksha.Core");

            entity.Property(e => e.Id).ValueGeneratedNever();
        });

        modelBuilder.Entity<TenantAssessmentReview>(entity =>
        {
            entity.ToTable("TenantAssessmentReviews", "Yaksha.Core");

            entity.HasIndex(e => e.AssessmentId, "IX_TenantAssessmentReviews_AssessmentId");

            entity.Property(e => e.ReviewSignedOffBy).HasDefaultValueSql("(CONVERT([bigint],(0)))");

            entity.HasOne(d => d.Assessment).WithMany(p => p.TenantAssessmentReviews).HasForeignKey(d => d.AssessmentId);
        });

        modelBuilder.Entity<TenantCatalog>(entity =>
        {
            entity.ToTable("TenantCatalogs", "Yaksha.Core");

            entity.HasIndex(e => e.CatalogId, "IX_TenantCatalogs_CatalogId");

            entity.HasOne(d => d.Catalog).WithMany(p => p.TenantCatalogs).HasForeignKey(d => d.CatalogId);
        });

        modelBuilder.Entity<TenantConfiguration>(entity =>
        {
            entity.ToTable("TenantConfigurations", "Yaksha.Core");
        });

        modelBuilder.Entity<TenantManager>(entity =>
        {
            entity.ToTable("TenantManagers", "Yaksha.Core");
        });

        modelBuilder.Entity<TenantQuestionBank>(entity =>
        {
            entity.ToTable("TenantQuestionBanks", "Yaksha.Core");

            entity.HasIndex(e => e.QuestionBankId, "IX_TenantQuestionBanks_QuestionBankId");

            entity.HasOne(d => d.QuestionBank).WithMany(p => p.TenantQuestionBanks).HasForeignKey(d => d.QuestionBankId);
        });

        modelBuilder.Entity<TenantQuestions20221031>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("tenantQuestions_20221031");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Keyword).HasColumnName("keyword");
            entity.Property(e => e.Questiontext).HasColumnName("questiontext");
        });

        modelBuilder.Entity<TenantQuestions20221125>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("tenantQuestions_20221125");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Keyword).HasColumnName("keyword");
            entity.Property(e => e.Questiontext).HasColumnName("questiontext");
        });

        modelBuilder.Entity<TestCase>(entity =>
        {
            entity.ToTable("TestCases", "Yaksha.Core");

            entity.HasIndex(e => e.QuestionId, "IX_TestCases_QuestionId");

            entity.Property(e => e.Score).HasColumnType("decimal(18, 2)");

            entity.HasOne(d => d.Question).WithMany(p => p.TestCases).HasForeignKey(d => d.QuestionId);
        });

        modelBuilder.Entity<TestCaseConstraint>(entity =>
        {
            entity.ToTable("TestCaseConstraints", "Yaksha.Core");

            entity.HasIndex(e => e.TestCaseId, "IX_TestCaseConstraints_TestCaseId");

            entity.HasOne(d => d.TestCase).WithMany(p => p.TestCaseConstraints).HasForeignKey(d => d.TestCaseId);
        });

        modelBuilder.Entity<TestCaseImport>(entity =>
        {
            entity.ToTable("TestCaseImport", "Yaksha.Core");
        });

        modelBuilder.Entity<TestCases20221031>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("TestCases_20221031", "Yaksha.Core");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
            entity.Property(e => e.Score).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<TestCases20221125>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("TestCases_20221125", "Yaksha.Core");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
            entity.Property(e => e.Score).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<UpdatedMessage>(entity =>
        {
            entity.HasNoKey();
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.ToTable("Users", "Yaksha.Core");

            entity.HasIndex(e => e.TenantId, "IX_Users_TenantId");

            entity.Property(e => e.Id).ValueGeneratedNever();

            entity.HasOne(d => d.Tenant).WithMany(p => p.Users).HasForeignKey(d => d.TenantId);
        });

        modelBuilder.Entity<UserAssessmentAttemptDetail>(entity =>
        {
            entity.ToTable("UserAssessmentAttemptDetails", "Yaksha.Core");

            entity.HasIndex(e => e.UserAssessmentMappingId, "IX_UserAssessmentAttemptDetails_UserAssessmentMappingId");

            entity.Property(e => e.Score).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ScorePercentage).HasColumnType("decimal(18, 2)");

            entity.HasOne(d => d.UserAssessmentMapping).WithMany(p => p.UserAssessmentAttemptDetails).HasForeignKey(d => d.UserAssessmentMappingId);
        });

        modelBuilder.Entity<UserAssessmentAttemptDetails2403>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("UserAssessmentAttemptDetails_2403", "Yaksha.Core");

            entity.Property(e => e.Id).ValueGeneratedOnAdd();
            entity.Property(e => e.Score).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ScorePercentage).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<UserAssessmentAttemptProficiency>(entity =>
        {
            entity.ToTable("UserAssessmentAttemptProficiencies", "Yaksha.Core");

            entity.HasIndex(e => e.UserAssessmentAttemptDetailId, "IX_UserAssessmentAttemptProficiencies_UserAssessmentAttemptDetailId");

            entity.Property(e => e.ScorePercentage).HasColumnType("decimal(18, 2)");

            entity.HasOne(d => d.UserAssessmentAttemptDetail).WithMany(p => p.UserAssessmentAttemptProficiencies).HasForeignKey(d => d.UserAssessmentAttemptDetailId);
        });

        modelBuilder.Entity<UserAssessmentAttemptQuestion>(entity =>
        {
            entity.ToTable("UserAssessmentAttemptQuestions", "Yaksha.Core");

            entity.HasIndex(e => e.AssessmentSectionSkillId, "IX_UserAssessmentAttemptQuestions_AssessmentSectionSkillId");

            entity.HasIndex(e => e.QuestionId, "IX_UserAssessmentAttemptQuestions_QuestionId");

            entity.Property(e => e.Score).HasColumnType("decimal(18, 2)");

            entity.HasOne(d => d.AssessmentSectionSkill).WithMany(p => p.UserAssessmentAttemptQuestions).HasForeignKey(d => d.AssessmentSectionSkillId);

            entity.HasOne(d => d.Question).WithMany(p => p.UserAssessmentAttemptQuestions).HasForeignKey(d => d.QuestionId);
        });

        modelBuilder.Entity<UserAssessmentAttemptSection>(entity =>
        {
            entity.ToTable("UserAssessmentAttemptSections", "Yaksha.Core");

            entity.HasIndex(e => e.UserAssessmentAttemptDetailId, "IX_UserAssessmentAttemptSections_UserAssessmentAttemptDetailId");

            entity.Property(e => e.Score).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.TimeTaken).HasDefaultValueSql("(CONVERT([bigint],(0)))");

            entity.HasOne(d => d.UserAssessmentAttemptDetail).WithMany(p => p.UserAssessmentAttemptSections).HasForeignKey(d => d.UserAssessmentAttemptDetailId);
        });

        modelBuilder.Entity<UserAssessmentCodingBasedResult>(entity =>
        {
            entity.ToTable("UserAssessmentCodingBasedResults", "Yaksha.Core");

            entity.HasIndex(e => e.UserAssessmentAttemptQuestionId, "IX_UserAssessmentCodingBasedResults_UserAssessmentAttemptQuestionId");

            entity.HasOne(d => d.UserAssessmentAttemptQuestion).WithMany(p => p.UserAssessmentCodingBasedResults).HasForeignKey(d => d.UserAssessmentAttemptQuestionId);
        });

        modelBuilder.Entity<UserAssessmentMapping>(entity =>
        {
            entity.ToTable("UserAssessmentMappings", "Yaksha.Core");

            entity.HasIndex(e => e.AssessmentScheduleId, "IX_UserAssessmentMappings_AssessmentScheduleId");

            entity.HasIndex(e => e.UserId, "IX_UserAssessmentMappings_UserId");

            entity.Property(e => e.CurrentScore).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CurrentScorePercentage).HasColumnType("decimal(18, 2)");

            entity.HasOne(d => d.AssessmentSchedule).WithMany(p => p.UserAssessmentMappings).HasForeignKey(d => d.AssessmentScheduleId);

            entity.HasOne(d => d.User).WithMany(p => p.UserAssessmentMappings).HasForeignKey(d => d.UserId);
        });

        modelBuilder.Entity<UserAssessmentScheduleInvite>(entity =>
        {
            entity.ToTable("UserAssessmentScheduleInvites", "Yaksha.Core");

            entity.HasIndex(e => e.AssessmentScheduleId, "IX_UserAssessmentScheduleInvites_AssessmentScheduleId");

            entity.HasOne(d => d.AssessmentSchedule).WithMany(p => p.UserAssessmentScheduleInvites).HasForeignKey(d => d.AssessmentScheduleId);
        });

        modelBuilder.Entity<UserRole>(entity =>
        {
            entity.ToTable("UserRoles", "Yaksha.Core");

            entity.HasIndex(e => e.RoleId, "IX_UserRoles_RoleId");

            entity.HasIndex(e => e.UserId, "IX_UserRoles_UserId");

            entity.HasOne(d => d.Role).WithMany(p => p.UserRoles).HasForeignKey(d => d.RoleId);

            entity.HasOne(d => d.User).WithMany(p => p.UserRoles).HasForeignKey(d => d.UserId);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
