﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class SkillListBasedOnProduction
{
    public string? SkillName { get; set; }
}
