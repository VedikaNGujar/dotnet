﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class AssessmentDetail
{
    public string? YakshaTestNames { get; set; }
}
