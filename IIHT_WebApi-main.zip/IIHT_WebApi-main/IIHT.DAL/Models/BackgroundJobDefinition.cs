﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class BackgroundJobDefinition
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long CreatorUserId { get; set; }

    public int JobType { get; set; }

    public string? JobArgs { get; set; }

    public int TryCount { get; set; }

    public DateTime NextTryTime { get; set; }

    public DateTime LastTryTime { get; set; }

    public bool IsAbandoned { get; set; }

    public int Priority { get; set; }

    public virtual ICollection<JobMetadatum> JobMetadata { get; } = new List<JobMetadatum>();
}
