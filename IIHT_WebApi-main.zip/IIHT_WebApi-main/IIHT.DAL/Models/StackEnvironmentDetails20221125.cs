﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class StackEnvironmentDetails20221125
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public long QuestionId { get; set; }

    public string? InstructionDocumentUrl { get; set; }

    public string? Sku { get; set; }

    public string? ContainerImageUrl { get; set; }

    public string? GitTemplateUrl { get; set; }

    public int LanguageId { get; set; }

    public string? TestCaseDetails { get; set; }

    public int Score { get; set; }

    public string? ConfigJson { get; set; }
}
