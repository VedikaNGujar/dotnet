﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class ScheduleSectionSkillMetadatum
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public long AssessmentScheduleId { get; set; }

    public long AssessmentSectionSkillMetadataId { get; set; }

    public long ProficiencyId { get; set; }

    public int TotalQuestions { get; set; }

    public virtual AssessmentSchedule AssessmentSchedule { get; set; } = null!;
}
