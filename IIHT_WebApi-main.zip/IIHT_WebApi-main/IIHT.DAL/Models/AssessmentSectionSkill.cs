﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class AssessmentSectionSkill
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public long AssessmentSectionId { get; set; }

    public long SkillId { get; set; }

    public int Duration { get; set; }

    public int TotalQuestions { get; set; }

    public int QuestionBankScope { get; set; }

    public long? SubSkillId { get; set; }

    public long? SubSubSkillId { get; set; }

    public virtual AssessmentSection AssessmentSection { get; set; } = null!;

    public virtual ICollection<AssessmentSectionSkillMetadatum> AssessmentSectionSkillMetadata { get; } = new List<AssessmentSectionSkillMetadatum>();

    public virtual ICollection<AssessmentSectionSkillQuestion> AssessmentSectionSkillQuestions { get; } = new List<AssessmentSectionSkillQuestion>();

    public virtual Skill Skill { get; set; } = null!;

    public virtual ICollection<UserAssessmentAttemptQuestion> UserAssessmentAttemptQuestions { get; } = new List<UserAssessmentAttemptQuestion>();
}
