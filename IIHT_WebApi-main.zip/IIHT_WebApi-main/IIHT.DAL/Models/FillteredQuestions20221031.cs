﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class FillteredQuestions20221031
{
    public long? OldId { get; set; }

    public decimal? Questionid { get; set; }

    public string? Questiontext { get; set; }

    public long QuestionTypeId { get; set; }

    public long ParentQuestionTypeId { get; set; }

    public string? Choices { get; set; }

    public string? Answers { get; set; }

    public long ProficiencyId { get; set; }

    public string Config { get; set; } = null!;
}
