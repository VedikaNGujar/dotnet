﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class User
{
    public long Id { get; set; }

    public string? UserName { get; set; }

    public string? EmailAddress { get; set; }

    public string? Name { get; set; }

    public string? Surname { get; set; }

    public int? TenantId { get; set; }

    public bool IsActive { get; set; }

    public bool IsDeleted { get; set; }

    public string? PhoneNumber { get; set; }

    public string? ProfilePicture { get; set; }

    public string? AboutMe { get; set; }

    public string? IdNumber { get; set; }

    public long? BusinessUnitId { get; set; }

    public string? BusinessUnitName { get; set; }

    public string? SocialProfileConfig { get; set; }

    public bool IsLoginEnabled { get; set; }

    public DateTime? DateOfBirth { get; set; }

    public string? FatherName { get; set; }

    public string? NameOnIdCard { get; set; }

    public virtual Tenant? Tenant { get; set; }

    public virtual ICollection<UserAssessmentMapping> UserAssessmentMappings { get; } = new List<UserAssessmentMapping>();

    public virtual ICollection<UserRole> UserRoles { get; } = new List<UserRole>();
}
