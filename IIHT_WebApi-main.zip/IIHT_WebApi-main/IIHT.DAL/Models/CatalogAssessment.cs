﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class CatalogAssessment
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public long CatalogId { get; set; }

    public long AssessmentId { get; set; }

    public int Type { get; set; }

    public virtual Assessment Assessment { get; set; } = null!;

    public virtual CatalogDefinition Catalog { get; set; } = null!;
}
