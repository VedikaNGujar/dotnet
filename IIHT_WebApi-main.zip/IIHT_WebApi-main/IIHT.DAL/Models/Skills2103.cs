﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class Skills2103
{
    public string? Skills { get; set; }

    public string? F2 { get; set; }
}
