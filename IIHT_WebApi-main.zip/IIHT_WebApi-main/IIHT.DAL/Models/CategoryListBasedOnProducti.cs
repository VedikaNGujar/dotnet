﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class CategoryListBasedOnProducti
{
    public string? Categorys { get; set; }
}
