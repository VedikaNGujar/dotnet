﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class StackTemplateType
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public string? Name { get; set; }

    public string? ImageUrl { get; set; }
}
