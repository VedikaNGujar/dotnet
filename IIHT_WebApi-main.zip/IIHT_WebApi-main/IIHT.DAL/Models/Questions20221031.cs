﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class Questions20221031
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public string? QuestionIdNumber { get; set; }

    public string? QuestionText { get; set; }

    public long QuestionTypeId { get; set; }

    public long ParentQuestionTypeId { get; set; }

    public string? Choices { get; set; }

    public string? Answers { get; set; }

    public long CategoryId { get; set; }

    public long ProficiencyId { get; set; }

    public string? Author { get; set; }

    public string? Config { get; set; }

    public long Mark { get; set; }

    public long Duration { get; set; }

    public long Weight { get; set; }
}
