﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class QuestionLanguageImport
{
    public long Id { get; set; }

    public long JobMetadataId { get; set; }

    public string? QuestionIdNumber { get; set; }

    public string? AllowedLanguage { get; set; }

    public string? DefaultCode { get; set; }
}
