﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class CategorySkillMapping
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public long CategoryId { get; set; }

    public long SkillId { get; set; }

    public virtual Category Category { get; set; } = null!;

    public virtual Skill Skill { get; set; } = null!;
}
