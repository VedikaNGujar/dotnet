﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class UserAssessmentAttemptQuestion
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public long UserId { get; set; }

    public long UserAssessmentAttemptId { get; set; }

    public long AssessmentSectionId { get; set; }

    public long AssessmentSectionSkillId { get; set; }

    public long QuestionId { get; set; }

    public int IsMarkedForReview { get; set; }

    public bool IsSkipped { get; set; }

    public string? Answer { get; set; }

    public decimal? Score { get; set; }

    public long? HintsAvailed { get; set; }

    public string? HintsAvailedJson { get; set; }

    public long? Duration { get; set; }

    public long? ReviewerId { get; set; }

    public long? LanguageId { get; set; }

    public bool IsCodeSubmitted { get; set; }

    public string? ConfigJson { get; set; }

    public DateTime? ReviewedOn { get; set; }

    public string? RemoteCodeBaseUrl { get; set; }

    public int StackStatus { get; set; }

    public bool IsActive { get; set; }

    public string? BranchName { get; set; }

    public string? RepositoryName { get; set; }

    public double? PlagiarismScore { get; set; }

    public string? ScanId { get; set; }

    public string? ScanResultJson { get; set; }

    public int? ScanStatus { get; set; }

    public virtual AssessmentSectionSkill AssessmentSectionSkill { get; set; } = null!;

    public virtual Question Question { get; set; } = null!;

    public virtual ICollection<UserAssessmentCodingBasedResult> UserAssessmentCodingBasedResults { get; } = new List<UserAssessmentCodingBasedResult>();
}
