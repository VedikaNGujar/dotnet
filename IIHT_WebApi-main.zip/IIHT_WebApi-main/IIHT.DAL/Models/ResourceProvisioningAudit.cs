﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class ResourceProvisioningAudit
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public string? ResourceGroupName { get; set; }

    public string? ServicePlanName { get; set; }

    public int? MaxCount { get; set; }

    public long RegionId { get; set; }

    public int ActiveInstanceCount { get; set; }

    public bool IsStateMaintenance { get; set; }

    public int PlanSku { get; set; }

    public virtual SupportedRegion Region { get; set; } = null!;
}
