﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class TenantQuestionBank
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public int? TenantId { get; set; }

    public long QuestionBankId { get; set; }

    public bool IsVisible { get; set; }

    public virtual QuestionBank QuestionBank { get; set; } = null!;
}
