﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class UserAssessmentAttemptSection
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public long UserAssessmentAttemptDetailId { get; set; }

    public long AssessmentSectionId { get; set; }

    public long UserId { get; set; }

    public long Duration { get; set; }

    public decimal Score { get; set; }

    public long TimeTaken { get; set; }

    public int? ActualProgression { get; set; }

    public int? ActualRegression { get; set; }

    public virtual UserAssessmentAttemptDetail UserAssessmentAttemptDetail { get; set; } = null!;
}
