﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class UserAssessmentAttemptDetail
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public long UserAssessmentMappingId { get; set; }

    public int Status { get; set; }

    public int? ProctoringStatus { get; set; }

    public string? ProctoringResultJson { get; set; }

    public long Duration { get; set; }

    public decimal Score { get; set; }

    public decimal ScorePercentage { get; set; }

    public int AttemptNumber { get; set; }

    public DateTime? ActualStart { get; set; }

    public DateTime? ActualEnd { get; set; }

    public string? CustomField { get; set; }

    public DateTime? ReviewedOn { get; set; }

    public long? ReviewerId { get; set; }

    public double? PlagiarismScore { get; set; }

    public int? PlagiarismStatus { get; set; }

    public long? StackTemplateTypeId { get; set; }

    public int? SubmissionType { get; set; }

    public virtual ICollection<UserAssessmentAttemptProficiency> UserAssessmentAttemptProficiencies { get; } = new List<UserAssessmentAttemptProficiency>();

    public virtual ICollection<UserAssessmentAttemptSection> UserAssessmentAttemptSections { get; } = new List<UserAssessmentAttemptSection>();

    public virtual UserAssessmentMapping UserAssessmentMapping { get; set; } = null!;
}
