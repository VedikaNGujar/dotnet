﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class QuestionHintImport
{
    public long Id { get; set; }

    public long JobMetadataId { get; set; }

    public string? QuestionIdNumber { get; set; }

    public string? HintDescription { get; set; }
}
