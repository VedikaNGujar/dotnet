﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class Skills2
{
    public string? SkillName { get; set; }
}
