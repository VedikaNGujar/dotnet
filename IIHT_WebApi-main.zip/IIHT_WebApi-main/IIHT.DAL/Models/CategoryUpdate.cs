﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class CategoryUpdate
{
    public string? CategoryName { get; set; }

    public string? NewCategoryName { get; set; }

    public double? OldCategoryId { get; set; }

    public double? NewCategoryId { get; set; }
}
