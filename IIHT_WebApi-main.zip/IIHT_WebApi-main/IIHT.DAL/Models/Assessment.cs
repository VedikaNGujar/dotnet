﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class Assessment
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public string? Name { get; set; }

    public string? AssessmentIdNumber { get; set; }

    public string? Description { get; set; }

    public string? Instructions { get; set; }

    public int Duration { get; set; }

    public string? AuthorName { get; set; }

    public int ModeOfCreation { get; set; }

    public long? ParentAssessmentId { get; set; }

    public int TotalSections { get; set; }

    public int TotalQuestions { get; set; }

    public int TotalSkills { get; set; }

    public int TotalMarks { get; set; }

    public int NoOfAttempts { get; set; }

    public int PassPercentage { get; set; }

    public int Status { get; set; }

    public string? ProctoringConfig { get; set; }

    public int Type { get; set; }

    public int? AssessmentMode { get; set; }

    public string? AssessmentQuestionsConfig { get; set; }

    public int? SkillType { get; set; }

    public virtual ICollection<AssessmentCategory> AssessmentCategories { get; } = new List<AssessmentCategory>();

    public virtual ICollection<AssessmentSchedule> AssessmentSchedules { get; } = new List<AssessmentSchedule>();

    public virtual ICollection<AssessmentSection> AssessmentSections { get; } = new List<AssessmentSection>();

    public virtual ICollection<CatalogAssessment> CatalogAssessments { get; } = new List<CatalogAssessment>();

    public virtual ICollection<TenantAssessmentReview> TenantAssessmentReviews { get; } = new List<TenantAssessmentReview>();
}
