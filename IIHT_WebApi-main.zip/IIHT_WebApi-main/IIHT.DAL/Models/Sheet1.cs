﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class Sheet1
{
    public string? SkillName { get; set; }
}
