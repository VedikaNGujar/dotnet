﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class AssessmentSchedulesBackup
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public int? TenantId { get; set; }

    public long AssessmentId { get; set; }

    public string? ScheduleIdNumber { get; set; }

    public DateTime? StartDateTime { get; set; }

    public DateTime? EndDateTime { get; set; }

    public int TotalAttempts { get; set; }

    public int PassPercentage { get; set; }

    public int Duration { get; set; }

    public int? NegativeScorePercentage { get; set; }

    public string? Link { get; set; }

    public int Target { get; set; }

    public string? RestrictToDomain { get; set; }

    public bool SendResultsEmail { get; set; }

    public string? AssessmentConfig { get; set; }

    public bool EnableProctoring { get; set; }

    public string? ProctoringConfig { get; set; }

    public bool IsActive { get; set; }

    public string? ExternalScheduleConfigArgs { get; set; }

    public bool EnableWheeboxProctoring { get; set; }

    public string? WheeboxProctoringConfig { get; set; }
}
