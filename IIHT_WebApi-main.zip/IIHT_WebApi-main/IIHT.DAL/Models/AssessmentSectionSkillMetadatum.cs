﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class AssessmentSectionSkillMetadatum
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public long AssessmentSectionSkillId { get; set; }

    public long ParentQuestionTypeId { get; set; }

    public int TotalQuestions { get; set; }

    public bool IsAutomated { get; set; }

    public string? ConfigJson { get; set; }

    public virtual AssessmentSectionSkill AssessmentSectionSkill { get; set; } = null!;

    public virtual ICollection<AssessmentSectionSkillMetadataProficiency> AssessmentSectionSkillMetadataProficiencies { get; } = new List<AssessmentSectionSkillMetadataProficiency>();

    public virtual QuestionType ParentQuestionType { get; set; } = null!;
}
