﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class CompilerLanguage
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public string? Language { get; set; }

    public string? EditorLanguageCode { get; set; }

    public string? CompilerLanguageCode { get; set; }

    public string? CompilerVersion { get; set; }

    public string? CompilerVersionCode { get; set; }

    public string? EditorDefaultCode { get; set; }
}
