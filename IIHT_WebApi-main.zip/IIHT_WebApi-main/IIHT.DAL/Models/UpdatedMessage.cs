﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class UpdatedMessage
{
    public int Sno { get; set; }

    public int Id { get; set; }

    public string Message { get; set; } = null!;
}
