﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class AssessmentSection
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public long AssessmentId { get; set; }

    public string? SectionName { get; set; }

    public int Duration { get; set; }

    public int TotalQuestions { get; set; }

    public int TotalSkills { get; set; }

    public int SortOrder { get; set; }

    public virtual Assessment Assessment { get; set; } = null!;

    public virtual ICollection<AssessmentSectionSkill> AssessmentSectionSkills { get; } = new List<AssessmentSectionSkill>();
}
