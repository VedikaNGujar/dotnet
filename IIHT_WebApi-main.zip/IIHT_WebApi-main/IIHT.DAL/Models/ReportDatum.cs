﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class ReportDatum
{
    public long Id { get; set; }

    public int? TenantId { get; set; }

    public string? TenantName { get; set; }

    public long? UserId { get; set; }

    public string EmailAddress { get; set; } = null!;

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public long? ScheduleId { get; set; }

    public long UserAssessmentMappingId { get; set; }

    public long UserAssessmentAttemptId { get; set; }

    public long? AssessmentId { get; set; }

    public string? AssessmentName { get; set; }

    public string? LinkType { get; set; }

    public int? CutOff { get; set; }

    public int? Attempt { get; set; }

    public DateTime? AttemptActualStart { get; set; }

    public DateTime? AttemptActualEnd { get; set; }

    public long? AssessmentSectionId { get; set; }

    public string? SectionName { get; set; }

    public int? SectionPercentage { get; set; }

    public int? SectionSortOrder { get; set; }

    public int? Percentage { get; set; }

    public string? TimeTaken { get; set; }

    public int? Status { get; set; }

    public string? StatusName { get; set; }

    public string? ProctoringStatus { get; set; }

    public bool? AssessmentIsDeleted { get; set; }

    public string? ProctoringScore { get; set; }

    public string? AssessmentType { get; set; }

    public string? CustomField1 { get; set; }

    public string? CustomField2 { get; set; }

    public string? IdScanApprovedBy { get; set; }

    public long? ActualDuration { get; set; }

    public int? Type { get; set; }

    public int? ProficiencyId { get; set; }

    public int? TotalProgression { get; set; }

    public int? ActualProgression { get; set; }

    public int? TotalRegression { get; set; }

    public int? ActualRegression { get; set; }

    public int? AchievedProficiencyId { get; set; }

    public string? PlagiarismScore { get; set; }

    public string? PlagiarismStatus { get; set; }

    public string? SubmissionType { get; set; }
}
