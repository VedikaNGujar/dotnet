﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class Skill
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public string? Name { get; set; }

    public string? Description { get; set; }

    public int Level { get; set; }

    public string? ImageUrl { get; set; }

    public virtual ICollection<AssessmentSectionSkill> AssessmentSectionSkills { get; } = new List<AssessmentSectionSkill>();

    public virtual ICollection<CategorySkillMapping> CategorySkillMappings { get; } = new List<CategorySkillMapping>();

    public virtual ICollection<QuestionBankSkill> QuestionBankSkills { get; } = new List<QuestionBankSkill>();

    public virtual ICollection<QuestionSkillMapping> QuestionSkillMappingSkills { get; } = new List<QuestionSkillMapping>();

    public virtual ICollection<QuestionSkillMapping> QuestionSkillMappingSubSkill2s { get; } = new List<QuestionSkillMapping>();

    public virtual ICollection<QuestionSkillMapping> QuestionSkillMappingSubSkills { get; } = new List<QuestionSkillMapping>();
}
