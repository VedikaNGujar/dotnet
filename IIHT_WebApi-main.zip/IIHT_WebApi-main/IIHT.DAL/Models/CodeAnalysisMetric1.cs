﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class CodeAnalysisMetric1
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public long StackTestCaseEvaluationResultId { get; set; }

    public string? FileName { get; set; }

    public int LineNumber { get; set; }

    public string? Message { get; set; }

    public int Severity { get; set; }

    public int Type { get; set; }
}
