﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class UserAssessmentAttemptDetails2403
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public long UserAssessmentMappingId { get; set; }

    public int Status { get; set; }

    public int? ProctoringStatus { get; set; }

    public string? ProctoringResultJson { get; set; }

    public long Duration { get; set; }

    public decimal Score { get; set; }

    public decimal ScorePercentage { get; set; }

    public int AttemptNumber { get; set; }

    public DateTime? ActualStart { get; set; }

    public DateTime? ActualEnd { get; set; }
}
