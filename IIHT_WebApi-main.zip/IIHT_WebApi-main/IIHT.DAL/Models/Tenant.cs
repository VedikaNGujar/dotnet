﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class Tenant
{
    public int Id { get; set; }

    public string? TenancyName { get; set; }

    public string? Name { get; set; }

    public bool IsActive { get; set; }

    public bool IsDeleted { get; set; }

    public virtual ICollection<User> Users { get; } = new List<User>();
}
