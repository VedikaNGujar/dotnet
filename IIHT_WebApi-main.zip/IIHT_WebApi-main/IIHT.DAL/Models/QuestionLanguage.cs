﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class QuestionLanguage
{
    public long QuestionId { get; set; }

    public long LanguageId { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public string? DefaultCode { get; set; }

    public virtual Question Question { get; set; } = null!;
}
