﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class CatalogDefinition
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public string? CatalogName { get; set; }

    public int CatalogType { get; set; }

    public bool IsActive { get; set; }

    public virtual ICollection<CatalogAssessmentSchedule> CatalogAssessmentSchedules { get; } = new List<CatalogAssessmentSchedule>();

    public virtual ICollection<CatalogAssessment> CatalogAssessments { get; } = new List<CatalogAssessment>();

    public virtual ICollection<TenantCatalog> TenantCatalogs { get; } = new List<TenantCatalog>();
}
