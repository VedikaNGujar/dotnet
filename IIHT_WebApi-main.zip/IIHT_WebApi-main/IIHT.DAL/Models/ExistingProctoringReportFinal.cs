﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class ExistingProctoringReportFinal
{
    public double? UserId { get; set; }

    public double? UserAssessmentAttemptDetailId { get; set; }

    public double? ProctoringScore { get; set; }

    public string? StudentId { get; set; }

    public string? EventId { get; set; }

    public string? ErrorMessage { get; set; }
}
