﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class Skill4
{
    public string? SkillName { get; set; }
}
