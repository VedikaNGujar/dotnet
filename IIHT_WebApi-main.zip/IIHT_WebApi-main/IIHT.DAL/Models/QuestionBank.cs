﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class QuestionBank
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public string? Name { get; set; }

    public int Scope { get; set; }

    public int Type { get; set; }

    public string? ConfigJson { get; set; }

    public virtual ICollection<QuestionBankItem> QuestionBankItems { get; } = new List<QuestionBankItem>();

    public virtual ICollection<QuestionBankSkill> QuestionBankSkills { get; } = new List<QuestionBankSkill>();

    public virtual ICollection<TenantQuestionBank> TenantQuestionBanks { get; } = new List<TenantQuestionBank>();
}
