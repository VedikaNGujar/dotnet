﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class QuestionImport
{
    public long Id { get; set; }

    public long JobMetadataId { get; set; }

    public long? QuestionId { get; set; }

    public string? QuestionIdNumber { get; set; }

    public string? QuestionText { get; set; }

    public string? QuestionType { get; set; }

    public string? Choices { get; set; }

    public string? Answers { get; set; }

    public string? CategoryName { get; set; }

    public string? SkillName { get; set; }

    public string? SubSkillName { get; set; }

    public string? SubSkill2Name { get; set; }

    public long Mark { get; set; }

    public long Duration { get; set; }

    public string? CourseName { get; set; }

    public string? ModuleName { get; set; }

    public string? Author { get; set; }

    public string? ProficiencyName { get; set; }

    public string? TenantName { get; set; }

    public string? ContentType { get; set; }

    public string? ContentUrl { get; set; }

    public string? ErrorMessage { get; set; }

    public virtual JobMetadatum JobMetadata { get; set; } = null!;
}
