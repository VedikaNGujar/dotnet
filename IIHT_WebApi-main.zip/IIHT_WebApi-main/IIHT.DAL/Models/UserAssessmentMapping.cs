﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class UserAssessmentMapping
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public int? TenantId { get; set; }

    public long UserId { get; set; }

    public long AssessmentScheduleId { get; set; }

    public long AssessmentId { get; set; }

    public long MaxAttempts { get; set; }

    public long AvailedAttempts { get; set; }

    public int Status { get; set; }

    public decimal CurrentScore { get; set; }

    public long CurrentDuration { get; set; }

    public decimal CurrentScorePercentage { get; set; }

    public string? ExternalArgs { get; set; }

    public virtual AssessmentSchedule AssessmentSchedule { get; set; } = null!;

    public virtual User User { get; set; } = null!;

    public virtual ICollection<UserAssessmentAttemptDetail> UserAssessmentAttemptDetails { get; } = new List<UserAssessmentAttemptDetail>();
}
