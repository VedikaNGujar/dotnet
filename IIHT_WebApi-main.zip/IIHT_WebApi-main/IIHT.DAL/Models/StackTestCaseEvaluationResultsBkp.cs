﻿using System;
using System.Collections.Generic;

namespace IIHT.DAL.Models;

public partial class StackTestCaseEvaluationResultsBkp
{
    public long Id { get; set; }

    public DateTime CreationTime { get; set; }

    public long? CreatorUserId { get; set; }

    public DateTime? LastModificationTime { get; set; }

    public long? LastModifierUserId { get; set; }

    public bool IsDeleted { get; set; }

    public long? DeleterUserId { get; set; }

    public DateTime? DeletionTime { get; set; }

    public int? TenantId { get; set; }

    public long UserId { get; set; }

    public long AssessmentScheduleId { get; set; }

    public long UserAssessmentMappingId { get; set; }

    public long UserAssessmentAttemptId { get; set; }

    public long QuestionId { get; set; }

    public string? TestCaseResultJson { get; set; }

    public string? RemoteCodeBaseUrl { get; set; }

    public int Status { get; set; }

    public string? TestCaseConfig { get; set; }

    public int Score { get; set; }

    public bool IsTestCaseViolated { get; set; }

    public int EvaluationStatus { get; set; }

    public string? ErrorResults { get; set; }

    public string? AnalysisResultJson { get; set; }

    public string? RepositoryName { get; set; }
}
