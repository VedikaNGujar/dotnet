﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IIHT.DAL.Helper
{
    public static class LanguageHelper
    {
        public static string GetExtensionForLanguage(string langugaeCode)
        {
            switch (langugaeCode.ToLowerInvariant())
            {
                case "c": return ".c";
                case "c++": return ".cpp";
                case "c#": return ".cs";
                case "java": return ".java";
                case "javascript": return ".js";
                case "python 3":return ".py";
            }
            return ".txt";
        }
    }
}
