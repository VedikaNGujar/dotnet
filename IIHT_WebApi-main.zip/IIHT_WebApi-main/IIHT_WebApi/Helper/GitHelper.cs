﻿using LibGit2Sharp;
using System.IO.Compression;

namespace IIHT.WebApi.Helper
{
    public static class GitHelper
    {
        public static void GitClone(string sourceGitUrl, string workingDirectoryPath)
        {
            if (!Directory.Exists(workingDirectoryPath))
            {
                Directory.CreateDirectory(workingDirectoryPath);
            }
            Repository.Clone(sourceGitUrl, workingDirectoryPath);
        }
       
    }
}
