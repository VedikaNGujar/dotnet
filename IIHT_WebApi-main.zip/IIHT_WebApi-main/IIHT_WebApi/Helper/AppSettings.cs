﻿namespace IIHT.WebApi.Helper
{
    public class AppSettings
    {
        public string GitDowloadPath { get; set; }
        public string MultipleAssessmentPath { get; set; }
        public string SingleAssessmentPath { get; set; }


    }
}
