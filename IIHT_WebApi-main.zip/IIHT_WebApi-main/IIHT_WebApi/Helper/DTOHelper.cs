﻿using IIHT.DAL.Entities;
using IIHT.WebApi.DataModels;
using static System.Net.WebRequestMethods;

namespace IIHT.WebApi.Helper
{
    public static class DTOHelper
    {
        public static IEnumerable<SingleFileAssessment> ToSingleFileAssessments(this IEnumerable<UserAssessmentDetail> userAssessmentAttemptQuestions)
        {
            return userAssessmentAttemptQuestions.Select(x =>
            new SingleFileAssessment()
            {
                Answer = x.Answer,
                ProgrammingLanguage = x.Language,
                ProgrammingLanguageId = x.LanguageId,
                Student = new Student(x.UserId, x.Name, x.UserAssessmentAttemptQuestionId),
                Template = new Template(x.QuestionId, x.DefaultCode)
            });
        }

        public static IEnumerable<MultipleFileAssessment> ToMultipleFileAssessments(this IEnumerable<UserAssessmentDetail> userAssessmentAttemptQuestions)
        {
            return userAssessmentAttemptQuestions.Select(x =>
            new MultipleFileAssessment()
            {
                GitURL = x.GitURL,
                ScanConfigDetails = x.ScanConfigDetails,
                ProgrammingLanguage = x.Language,
                ProgrammingLanguageId = x.LanguageId,
                Student = new Student(x.UserId, x.Name, x.UserAssessmentAttemptQuestionId),
                Template = new Template(x.QuestionId, x.TemplateURL)
            });
        }
    }
}
