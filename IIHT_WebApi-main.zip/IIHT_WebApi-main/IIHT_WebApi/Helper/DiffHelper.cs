﻿using DiffMatchPatch;
using System.Text;

namespace IIHT.WebApi.Helper
{
    public static class DiffHelper
    {
        public static string CompareContentWithTemplate(string content, string template)
        {
            StringBuilder result = new StringBuilder();

            diff_match_patch dmp = new diff_match_patch();
            List<Diff> diff = dmp.diff_main(template, content, true);
            dmp.diff_cleanupSemantic(diff);
            for (int i = 0; i < diff.Count; i++)
            {
                if (diff[i].operation == Operation.INSERT)
                {
                    result.Append(diff[i].text);
                }
            }
            return result.ToString();
        }
    }
}
