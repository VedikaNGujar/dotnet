﻿using IIHT.WebApi.DataModels;
using System.Text.RegularExpressions;

namespace IIHT.WebApi.Helper
{
    public static class StringHelpers
    {
        public static Student getStudentDetails(this string path)
        {
            string[] arr = path.Split("\\");
            if (arr.Length > 0)
            {
                string[] str = arr[arr.Length - 1].Split("_");
                return new Student(Convert.ToInt32(str[1]), str[0], Convert.ToInt32(str[2]));
            }
            return null;
        }

        public static string shortenFileName(this string path)
        {
            string[] arr = path.Split("\\");
            if (arr.Length > 0)
            {
                return arr[arr.Length - 1];
            }
            return path;
        }

    }
}
