﻿namespace IIHT.WebApi.Helper
{
    public static class XMLHelper
    {
        public static T Deserialize<T>(string xmlValue)
        {
            var reader = new System.Xml.Serialization.XmlSerializer(typeof(T));
            System.IO.StringReader file = new System.IO.StringReader(xmlValue);
            T obj = (T)reader.Deserialize(file);
            return obj;
        }
    }
}
