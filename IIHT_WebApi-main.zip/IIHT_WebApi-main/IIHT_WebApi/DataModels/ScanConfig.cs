﻿using System.Xml.Serialization;

namespace IIHT.WebApi.DataModels
{
    [XmlRoot(ElementName = "scanConfig")]

    public class ScanConfig
    {
        [XmlElement(ElementName = "excludeFolders")]
        public ExcludeFolders ExcludeFolders { get; set; }
        [XmlElement(ElementName = "excludeFiles")]
        public ExcludeFiles ExcludeFiles { get; set; }
    }

    [XmlRoot(ElementName = "excludeFolders")]
    public class ExcludeFolders
    {
        [XmlElement(ElementName = "excludeFolder")]
        public List<string> ExcludeFolder { get; set; }
    }

    [XmlRoot(ElementName = "excludeFiles")]
    public class ExcludeFiles
    {
        [XmlElement(ElementName = "excludeFile")]
        public List<string> ExcludeFile { get; set; }
    }
}
