﻿using System.Text.Json.Serialization;
using System.Xml.Linq;

namespace IIHT.WebApi.DataModels
{
    public class Student
    {
        public Student(long studentId, string studentName, long studentAttemptId)
        {
            this.StudentId = studentId;
            this.StudentName = studentName;
            this.StudentAttemptId = studentAttemptId;
        }

        [JsonPropertyOrder(1)]
        public long StudentId { get; set; }

        [JsonPropertyOrder(2)]
        public string StudentName { get; set; }

        [JsonPropertyOrder(3)]
        public long StudentAttemptId { get; set; }

        public override bool Equals(object obj)
        {
            return (obj is Student)
                && ((Student)obj).StudentName.Equals(StudentName)
                && ((Student)obj).StudentId.Equals(StudentId)
                && ((Student)obj).StudentAttemptId.Equals(StudentAttemptId);
        }

        public override int GetHashCode()
        {
            return StudentId.GetHashCode() ^ StudentName.GetHashCode() ^ StudentAttemptId.GetHashCode();
        }
    }

}
