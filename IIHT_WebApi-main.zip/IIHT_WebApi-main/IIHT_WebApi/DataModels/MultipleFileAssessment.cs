﻿namespace IIHT.WebApi.DataModels
{
    public class MultipleFileAssessment : Assessment
    {
        public string GitURL { get; set; }
        public string ScanConfigDetails  { get; set; }
        public Template Template { get; set; }
        public List<string> FilesToCompare { get; set; } = new();
    }
}
