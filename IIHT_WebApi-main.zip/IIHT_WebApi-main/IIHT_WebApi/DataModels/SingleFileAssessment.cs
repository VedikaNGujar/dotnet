﻿using IIHT.WebApi.Helper;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System.Net.Http.Headers;

namespace IIHT.WebApi.DataModels
{
    public class SingleFileAssessment : Assessment
    {
        public string Answer { get; set; }
        public Template Template { get; set; }        
    }


}
