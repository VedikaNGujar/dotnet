﻿namespace IIHT.WebApi.DataModels
{
    public class Template
    {
        public Template(long templateId, string templateCode)
        {
            TemplateId = templateId;
            TemplateCode = templateCode;
        }

        public long TemplateId { get; set; }
        public string TemplateCode { get; set; }
    }
}
