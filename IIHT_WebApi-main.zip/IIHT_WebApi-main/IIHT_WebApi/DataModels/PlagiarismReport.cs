﻿using System.Text.Json.Serialization;

namespace IIHT.WebApi.DataModels
{
    public class PlagiarismReport
    {
        public long LanguageId { get; set; }
        public List<StudentScore> StudentScores { get; set; }
    }

    public class StudentScore : Student
    {
        public StudentScore(long studentId, string studentName, long studentAttemptId)
            : base(studentId, studentName, studentAttemptId)
        {
        }

        [JsonPropertyOrder(5)]
        public double PlagiarismScore { get; set; }
        [JsonPropertyOrder(6)]
        public List<Score> Score { get; set; }
    }

    public class Score
    {
        public string File { get; set; }
        public double SimilarityPercentage { get; set; }
        public string ComparisionFile { get; set; }
        public double LongestFragment { get; set; }
    }

    public class Similarity
    {
        public double Longest { get; set; }
        public double similarity { get; set; }
        public CodeFile LeftFile { get; set; }
        public CodeFile RightFile { get; set; }
    }

    public class CodeFile
    {
        public string Path { get; set; }
    }

}
