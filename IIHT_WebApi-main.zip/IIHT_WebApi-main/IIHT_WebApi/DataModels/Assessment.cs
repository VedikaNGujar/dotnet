﻿using IIHT.DAL.Helper;

namespace IIHT.WebApi.DataModels
{

    public class Assessment
    {
        public Student Student { get; set; }
        public long ProgrammingLanguageId { get; set; }
        public string ProgrammingLanguage { get; set; }
        public string LanguageCodeExtension => LanguageHelper.GetExtensionForLanguage(ProgrammingLanguage);

    }

}
