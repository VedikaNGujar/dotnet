using IIHT.DAL;
using IIHT.DAL.Contracts;
using IIHT.DAL.Models;
using IIHT.DAL.Repositories;
using IIHT.WebApi.Helper;
using IIHT.WebApi.Services;
using Jering.Javascript.NodeJS;
using Serilog;
using ServiceAPI.Services;

var configuration = new ConfigurationBuilder()
        .SetBasePath(Directory.GetCurrentDirectory())
        .AddJsonFile("appsettings.json")
        .AddJsonFile($"appsettings.{Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Production"}.json", true)
        .Build();

var logger = new LoggerConfiguration()
    // Read from appsettings.json
    .ReadFrom.Configuration(configuration)
    .Enrich.FromLogContext()
    // Create the actual logger
    .CreateLogger();

var builder = WebApplication.CreateBuilder(args);
builder.Logging.ClearProviders();
builder.Logging.AddSerilog(logger);

// Add services to the container.
builder.Services.Configure<AppSettings>(builder.Configuration.GetSection("AppSettings"));

 
builder.Services.AddSingleton<StageYakshaCoreContext>();
builder.Services.AddScoped<IUserAssessmentAttemptQuestionRepository, UserAssessmentAttemptQuestionRepository>();

builder.Services.AddTransient<IPlagiarismService, PlagiarismService>();
builder.Services.AddTransient<IReportService, ReportService>();
builder.Services.AddTransient<IFileService, FileService>();

builder.Services.AddNodeJS();

string dolosLibPath = Directory.GetCurrentDirectory() + "\\JSLibrary";
builder.Services.Configure<NodeJSProcessOptions>(options => options.ProjectPath = dolosLibPath);


builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
