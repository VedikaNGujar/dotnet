﻿using IIHT.WebApi.DataModels;
using IIHT.WebApi.Services;
using Jering.Javascript.NodeJS;
using System.Collections.Concurrent;

namespace ServiceAPI.Services
{
    public class PlagiarismService : IPlagiarismService
    {
        private readonly INodeJSService _nodeJSService;
        private readonly IReportService _reportService;
        private readonly ILogger<PlagiarismService> _logger;

        public PlagiarismService(INodeJSService serviceProvider,
            IReportService reportService,
            ILogger<PlagiarismService> logger)
        {
            _nodeJSService = serviceProvider;
            _reportService = reportService;
            _logger = logger;
        }

        /// <summary>
        /// Analyze the plagiarism for multiple file assessments
        /// </summary>
        /// <param name="files"></param>
        /// <param name="programmingLanguageId"></param>
        /// <returns></returns>
        public PlagiarismReport AnalyzeFiles(List<MultipleFileAssessment> files, long programmingLanguageId)
        {
            _logger.LogInformation("Begin AnalyzeFiles");
            try
            {
                var scores = new ConcurrentBag<List<Score>>();
                var templates = files
                    .GroupBy(x => x.Template.TemplateId)
                    .Select(x => new
                    {
                        templateId = x.Key,
                        filePaths = x.Select(y => y.FilesToCompare).ToList()
                    }).ToList();

                Parallel.ForEach(templates, template =>
                {
                    //foreach (var template in templates)
                    //{
                    var fileCount = template.filePaths.Count();
                    var filePathsCounts = template.filePaths.First().Count();
                    List<string> filePaths = new();
                    for (int i = 0; i < filePathsCounts; i++)
                    {
                        List<Similarity> similarities = new();
                        filePaths = new();
                        for (int j = 0; j < fileCount; j++)
                        {
                            filePaths.Add(template.filePaths[j][i]);
                        }
                        similarities = _nodeJSService.InvokeFromFileAsync<List<Similarity>>("plagiarismAnalysis.js", args: new object[] { filePaths }).Result;
                        scores.Add(_reportService.GenerateScores(filePaths, similarities));
                    }
                    //}
                });


                var report = new PlagiarismReport()
                {
                    LanguageId = programmingLanguageId,
                    StudentScores = _reportService.GenerateReport(scores.SelectMany(x => x).ToList()),
                };
                return report;
            }
            catch (Exception ex)
            {
                _logger.LogError($"AnalyzeFiles: {ex.Message}");
            }
            _logger.LogInformation("End AnalyzeFiles");
            return null;

        }

        /// <summary>
        /// Analyze the plagiarism for single file assessments
        /// </summary>
        /// <param name="files"></param>
        /// <param name="programmingLanguageId"></param>
        /// <returns></returns>
        public PlagiarismReport AnalyzeFiles(List<SingleFileAssessment> files, long programmingLanguageId)
        {
            _logger.LogInformation("Begin AnalyzeFiles");

            try
            {
                var scores = new ConcurrentBag<List<Score>>();
                var templates = files
                    .GroupBy(x => x.Template.TemplateId)
                    .Select(x => new
                    {
                        templateId = x.Key,
                        filePaths = x.Select(y => y.Answer).ToList()
                    });

                Parallel.ForEach(templates, template =>
                {
                    //foreach (var template in templates)
                    //{
                    List<Similarity> similarities = new();
                    if (template.filePaths.Count > 1)
                    {
                        similarities = _nodeJSService.InvokeFromFileAsync<List<Similarity>>("plagiarismAnalysis.js", args: new object[] { template.filePaths }).Result;
                    }
                    scores.Add(_reportService.GenerateScores(template.filePaths, similarities));
                    //}
                });

                var report = new PlagiarismReport()
                {
                    LanguageId = programmingLanguageId,
                    StudentScores = _reportService.GenerateReport(scores.SelectMany(x => x).ToList())
                };

                return report;
            }
            catch (Exception ex)
            {
                _logger.LogError($"AnalyzeFiles: {ex.Message}");
            }

            _logger.LogInformation("End AnalyzeFiles");
            return null;
        }
    }
}
