﻿using IIHT.WebApi.DataModels;

namespace IIHT.WebApi.Services
{
    public interface IPlagiarismService
    {
        public PlagiarismReport AnalyzeFiles(List<SingleFileAssessment> files, long programmingLanguageId);
        public PlagiarismReport AnalyzeFiles(List<MultipleFileAssessment> files, long programmingLanguageId);
    }
}
