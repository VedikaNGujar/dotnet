﻿using IIHT.DAL.Models;
using IIHT.WebApi.DataModels;
using IIHT.WebApi.Helper;
using Microsoft.Extensions.Options;
using System.Collections.Concurrent;
using System.IO;

namespace IIHT.WebApi.Services
{
    internal class SingleFilePairDictionary
    {
        public long ProgrammingLanguageId { get; set; }
        public List<SingleFileAssessment> AssessmentList { get; set; }
    }

    public class FileService : IFileService
    {
        private readonly AppSettings _appSettings;

        private readonly ILogger<FileService> _logger;

        public FileService(IOptions<AppSettings> options, ILogger<FileService> logger)
        {
            _appSettings = options.Value;
            _logger = logger;
        }

        public Dictionary<long, List<MultipleFileAssessment>> CreateMultipleAssessmentFile(long assessmentScheduleId, IEnumerable<MultipleFileAssessment> multipleFileAssessments)
        {
            _logger.LogInformation("Begin CreateMultipleAssessmentFile");
            try
            {
                Dictionary<long, List<MultipleFileAssessment>> filePairs = new();

                var groups = multipleFileAssessments
                    .GroupBy(x => new { ProgrammingLanguageId = x.ProgrammingLanguageId })
                    .Select(x => new { ProgrammingLanguageId = x.Key.ProgrammingLanguageId, multipleFileAssessment = x.ToList() });

                foreach (var group in groups)
                {
                    foreach (var assessment in group.multipleFileAssessment)
                    {
                        DownloadGitCode(assessmentScheduleId, assessment);

                        var scanConfig = XMLHelper.Deserialize<ScanConfig>(assessment.ScanConfigDetails);

                        var gitFiles = Directory.GetFiles(assessment.GitURL, "*", SearchOption.AllDirectories).ToList();
                        var templateFiles = Directory.GetFiles(assessment.Template.TemplateCode, "*", SearchOption.AllDirectories).ToList();

                        for (int i = 0; i < gitFiles.Count; i++)
                        {
                            var file = gitFiles[i];
                            if (!scanConfig.ExcludeFolders.ExcludeFolder.Any(x => file.Contains(x))
                                && !scanConfig.ExcludeFiles.ExcludeFile.Any(x => file.Contains(x)))
                            {

                                var leftFileName = file;
                                var templateFileName = templateFiles[i];

                                //take out the difference content
                                var fileContent = DiffHelper.CompareContentWithTemplate(File.ReadAllText(leftFileName), File.ReadAllText(templateFileName));

                                var fileName = file.shortenFileName();
                                var directory = $"{_appSettings.MultipleAssessmentPath}\\{assessmentScheduleId}\\{group.ProgrammingLanguageId}";
                                var newFileName = $"{directory}\\{assessment.Student.StudentName}_{assessment.Student.StudentId}_{assessment.Student.StudentAttemptId}_{fileName}";
                                if (!Directory.Exists(directory))
                                {
                                    Directory.CreateDirectory(directory);
                                }
                                File.WriteAllText(newFileName, fileContent);
                                assessment.FilesToCompare.Add(newFileName);
                            }
                        }
                    }
                    filePairs.Add(group.ProgrammingLanguageId, group.multipleFileAssessment);
                }

                return filePairs;
            }
            catch (Exception ex)
            {
                _logger.LogError($"CreateMultipleAssessmentFile: {ex.Message}");

            }
            _logger.LogInformation("End CreateMultipleAssessmentFile");
            return null;

        }

        private void DownloadGitCode(long assessmentScheduleId, MultipleFileAssessment assessment)
        {
            var directoryForTemplates = $"{_appSettings.GitDowloadPath}\\{assessmentScheduleId}\\Template\\{assessment.Template.TemplateId}";
            //if we have already downloaded the template code we'll not download it again
            if (!Directory.Exists(directoryForTemplates))
            {
                //download template code from GIT URL
                GitHelper.GitClone(assessment.Template.TemplateCode, directoryForTemplates);
            }
            assessment.Template.TemplateCode = directoryForTemplates;


            var directoryForGitLocation = $"{_appSettings.GitDowloadPath}\\{assessmentScheduleId}\\{assessment.Student.StudentId}_{assessment.Student.StudentName}_{assessment.Student.StudentAttemptId}";
            if (Directory.Exists(directoryForGitLocation))
            {
                DeleteDirectory(directoryForGitLocation);
            }

            //download the code from GIT and save
            GitHelper.GitClone(assessment.GitURL, directoryForGitLocation);
            assessment.GitURL = directoryForGitLocation;
        }

        public Dictionary<long, List<SingleFileAssessment>> CreateSingleAssessmentFiles(long assessmentScheduleId, IEnumerable<SingleFileAssessment> singleFileAssessments)
        {
            _logger.LogInformation("Begin CreateSingleAssessmentFiles");

            try
            {
                ConcurrentBag<SingleFilePairDictionary> filePairs = new();

                var groups = singleFileAssessments
                    .GroupBy(x => new { ProgrammingLanguageId = x.ProgrammingLanguageId })
                    .Select(x => new { ProgrammingLanguageId = x.Key.ProgrammingLanguageId, singleFileAssessment = x.ToList() });

                Parallel.ForEach(groups, group =>
                {
                    var files = CreateFile(assessmentScheduleId, group.ProgrammingLanguageId, group.singleFileAssessment);
                    if (files.Any())
                        filePairs.Add(new SingleFilePairDictionary { AssessmentList = files, ProgrammingLanguageId = group.ProgrammingLanguageId });
                });

                return filePairs.GroupBy(x => x.ProgrammingLanguageId)
                    .ToDictionary(x => x.Key, x => x.SelectMany(y => y.AssessmentList).ToList());
            }
            catch (Exception ex)
            {
                _logger.LogError($"CreateSingleAssessmentFiles: {ex.Message}");

            }
            _logger.LogInformation("End CreateSingleAssessmentFiles");
            return null;

        }

        private List<SingleFileAssessment> CreateFile(long assessmentId, long programmingLanguageId, List<SingleFileAssessment> singleFileAssessments)
        {
            try
            {
                Parallel.ForEach(singleFileAssessments, assessment =>
                {
                    string content = assessment.Answer ?? string.Empty;
                    assessment.Answer = DiffHelper.CompareContentWithTemplate(content, System.Web.HttpUtility.HtmlDecode(assessment.Template.TemplateCode));
                    string directory = $"{_appSettings.SingleAssessmentPath}\\{assessmentId}\\{programmingLanguageId}";
                    // If directory does not exist, create it. 
                    if (!Directory.Exists(directory))
                    {
                        Directory.CreateDirectory(directory);
                    }
                    string path = $"{directory}\\{assessment.Student.StudentName}_{assessment.Student.StudentId}_{assessment.Student.StudentAttemptId}_{assessment.LanguageCodeExtension}";
                    File.WriteAllText(path, assessment.Answer);
                    assessment.Answer = path;

                });
                return singleFileAssessments;
            }
            catch (Exception ex)
            {
                _logger.LogError($"CreateFile: {ex.Message}");
                return null;
            }
        }
        public void DeleteSingleAssessmentFiles(long assessmentScheduleId)
        {
            try
            {
                if (Directory.Exists($"{_appSettings.SingleAssessmentPath}\\{assessmentScheduleId}"))
                {
                    DeleteDirectory($"{_appSettings.SingleAssessmentPath}\\{assessmentScheduleId}");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"DeleteSingleAssessmentFiles: {ex.Message}");
            }
        }

        public void DeleteMultipleAssessmentFiles(long assessmentScheduleId)
        {
            try
            {
                if (Directory.Exists($"{_appSettings.GitDowloadPath}\\{assessmentScheduleId}"))
                {
                    DeleteDirectory($"{_appSettings.GitDowloadPath}\\{assessmentScheduleId}");
                }
                if (Directory.Exists($"{_appSettings.MultipleAssessmentPath}\\{assessmentScheduleId}"))
                {
                    DeleteDirectory($"{_appSettings.MultipleAssessmentPath}\\{assessmentScheduleId}");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"DeleteMultipleAssessmentFiles: {ex.Message}");
            }
        }

        private static void DeleteDirectory(string directory)
        {
            foreach (string subdirectory in Directory.EnumerateDirectories(directory))
            {
                DeleteDirectory(subdirectory);
            }

            foreach (string fileName in Directory.EnumerateFiles(directory))
            {
                var fileInfo = new FileInfo(fileName)
                {
                    Attributes = FileAttributes.Normal
                };
                fileInfo.Delete();
            }

            Directory.Delete(directory);
        }
    }
}
