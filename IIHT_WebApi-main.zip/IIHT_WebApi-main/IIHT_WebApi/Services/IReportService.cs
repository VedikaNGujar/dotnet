﻿using IIHT.WebApi.DataModels;

namespace IIHT.WebApi.Services
{
    public interface IReportService
    {
        public List<StudentScore> GenerateReport(List<Score> scores);
        public List<Score> GenerateScores(List<string> files, List<Similarity> similarities);
    }
}
