﻿using IIHT.DAL.Entities;
using IIHT.WebApi.DataModels;

namespace IIHT.WebApi.Services
{
    public interface IFileService
    {
        public Dictionary<long, List<SingleFileAssessment>> CreateSingleAssessmentFiles(long assessmentScheduleId, IEnumerable<SingleFileAssessment> singleFileAssessments);
        public Dictionary<long, List<MultipleFileAssessment>> CreateMultipleAssessmentFile(long assessmentScheduleId, IEnumerable<MultipleFileAssessment> multipleFileAssessments);
        public void DeleteSingleAssessmentFiles(long assessmentScheduleId);
        public void DeleteMultipleAssessmentFiles(long assessmentScheduleId);

    }
}
