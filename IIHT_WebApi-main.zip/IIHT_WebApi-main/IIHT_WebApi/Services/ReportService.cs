﻿using IIHT.WebApi.DataModels;
using IIHT.WebApi.Helper;

namespace IIHT.WebApi.Services
{
    public class ReportService : IReportService
    {
        public List<StudentScore> GenerateReport(List<Score> scores)
        {
            return scores
                .GroupBy(x =>
                {
                    var stud = x.File.getStudentDetails();
                    return new Student(stud.StudentId, stud.StudentName, stud.StudentAttemptId);
                })
                .Select(x =>
                {
                    return new StudentScore(x.Key.StudentId, x.Key.StudentName, x.Key.StudentAttemptId)
                    {
                        PlagiarismScore = x.Select(x => x.SimilarityPercentage).Average(),
                        Score = x.Select(y => new Score()
                        {
                            File = y.File,
                            SimilarityPercentage = y.SimilarityPercentage,
                            ComparisionFile = y.ComparisionFile,
                            LongestFragment = y.LongestFragment
                        }).ToList()
                    };
                }).ToList();
        }

        public List<Score> GenerateScores(List<string> files, List<Similarity> similarities)
        {
            var result = new List<Score>();
            if (similarities == null || similarities.Any() == false)
            {
                result = files.Select(x => new Score()
                {
                    File = x,
                }).ToList();
            }
            else
            {
                foreach (var file in files)
                {
                    var obj = similarities
                        .Where(x => x.LeftFile.Path.Equals(file) || x.RightFile.Path.Equals(file))
                        .OrderByDescending(x => x.similarity)
                        .FirstOrDefault();

                    var score = new Score() { File = file };
                    if (obj != null)
                    {
                        score.SimilarityPercentage = obj.similarity * 100;
                        score.LongestFragment = obj.Longest;
                        score.ComparisionFile = obj.similarity == 0 ? "" : (file == obj.LeftFile.Path ? obj.RightFile.Path : obj.LeftFile.Path);
                    }
                    result.Add(score);
                }
            }
            return result;
        }
    }
}
