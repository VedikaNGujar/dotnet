﻿module.exports = async (paths) => {
    const dolos = require('@dodona/dolos-lib');
    let options = new dolos.Options;
    options.kgramLength = 10;
    const instance = new dolos.Dolos(options);
    const report = instance.analyzePaths(paths);
    return filterResponse(await report.then());
    function filterResponse(value) {
        let scoredPairs = value.allPairs();

        scoredPairs.forEach(element => {
            delete element.fragmentStart;
            delete element.fragmentEnd;
            delete element.leftFile.lines;
            delete element.leftFile.file;
            delete element.leftFile.extra;
            delete element.leftFile.shared;
            delete element.leftFile.ast;
            delete element.leftFile.mapping;
            delete element.leftFile.kgrams
            delete element.leftFile.charCount;

            delete element.rightFile.lines;
            delete element.rightFile.file;
            delete element.rightFile.extra;
            delete element.rightFile.shared;
            delete element.rightFile.ast;
            delete element.rightFile.mapping;
            delete element.rightFile.kgrams;
            delete element.rightFile.lineCount;
            delete element.rightFile.lineCount;
            delete element.rightFile.charCount;
        });
        return JSON.stringify(scoredPairs);
    }
}