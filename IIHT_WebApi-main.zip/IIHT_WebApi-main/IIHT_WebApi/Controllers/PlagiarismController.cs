﻿using IIHT.DAL.Contracts;
using IIHT.WebApi.DataModels;
using IIHT.WebApi.Helper;
using IIHT.WebApi.Services;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Concurrent;
using System.Text.Json;

namespace IIHT.WebApi.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class PlagiarismController : ControllerBase
    {
        private readonly IPlagiarismService _plagiarismService;
        private readonly IFileService _fileService;
        private readonly IUserAssessmentAttemptQuestionRepository _userAssessmentAttemptQuestionRepository;
        private readonly ILogger<PlagiarismController> _logger;

        public PlagiarismController(
            IPlagiarismService plagiarismService,
            IFileService fileService,
            IUserAssessmentAttemptQuestionRepository userAssessmentAttemptQuestionRepository,
            ILogger<PlagiarismController> logger)
        {
            _plagiarismService = plagiarismService;
            _fileService = fileService;
            _userAssessmentAttemptQuestionRepository = userAssessmentAttemptQuestionRepository;
            _logger = logger;
        }

        [HttpPost]
        public IActionResult PlagiarismCheckForSingleFileAssessment(long assessmentScheduleId)
        {
            /*
             * 1. Get all the user assessments
             * 2. Convert into SingleFileAssessment Obj
             * 3. Call Plagiarism Service
             * 4. Update the Assessments
             * 5. Return the result : boolean : true or false           
             */
            _logger.LogInformation("Begin PlagiarismCheckForSingleFileAssessment");
            try
            {
                var assessments = _userAssessmentAttemptQuestionRepository.GetUserAssessmentAttemptByAssessmentScheduleIdForSFA(assessmentScheduleId);
                var singleFileAssessments = assessments.ToSingleFileAssessments();

                if (singleFileAssessments.Any())
                {
                    var filePairs = _fileService.CreateSingleAssessmentFiles(assessmentScheduleId, singleFileAssessments);
                    if (filePairs.Any())
                    {
                        ConcurrentBag<PlagiarismReport> reports = new();
                        Parallel.ForEach(filePairs, item =>
                        {
                            var report = _plagiarismService.AnalyzeFiles(item.Value.ToList(), item.Key);
                            if (report != null)
                                reports.Add(report);
                        });

                        foreach (var report in reports.SelectMany(x => x.StudentScores))
                        {
                            _userAssessmentAttemptQuestionRepository.UpdatePlagiarismScore(
                                Convert.ToInt32(report.StudentAttemptId),
                                 report.PlagiarismScore,
                                 JsonSerializer.Serialize(report.Score));
                        }
                    }
                    _fileService.DeleteSingleAssessmentFiles(assessmentScheduleId);
                    _logger.LogInformation("End PlagiarismCheckForSingleFileAssessment");
                    return new OkObjectResult("Success");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"PlagiarismCheckForSingleFileAssessment: {ex.Message}");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
            _logger.LogInformation("End PlagiarismCheckForSingleFileAssessment");
            return new NoContentResult();
        }

        [HttpPost]
        public IActionResult PlagiarismCheckForMultipleFileAssessment(long assessmentScheduleId)
        {
            /*
             * 1. Get all the user assessments
             * 2. Convert into SingleFileAssessment Obj
             * 3. Call Plagiarism Service
             * 4. Update the Assessments
             * 5. Return the result : boolean : true or false           
             */
            _logger.LogInformation("Begin PlagiarismCheckForMultipleFileAssessment");

            try
            {
                var assessments = _userAssessmentAttemptQuestionRepository.GetUserAssessmentAttemptByAssessmentScheduleIdForMFA(assessmentScheduleId);
                var multipleFileAssessments = assessments.ToMultipleFileAssessments();

                if (multipleFileAssessments.Any())
                {
                    var filePairs = _fileService.CreateMultipleAssessmentFile(assessmentScheduleId, multipleFileAssessments);
                    ConcurrentBag<PlagiarismReport> reports = new();
                    Parallel.ForEach(filePairs, item =>
                    {
                        var report = _plagiarismService.AnalyzeFiles(item.Value.ToList(), item.Key);
                        if (report != null)
                            reports.Add(report);
                    });

                    foreach (var report in reports.SelectMany(x => x.StudentScores))
                    {
                        _userAssessmentAttemptQuestionRepository
                             .UpdatePlagiarismScore(Convert.ToInt32(report.StudentAttemptId),
                             report.PlagiarismScore,
                             JsonSerializer.Serialize(report.Score));
                    }
                    _fileService.DeleteMultipleAssessmentFiles(assessmentScheduleId);
                    _logger.LogInformation("End PlagiarismCheckForMultipleFileAssessment");
                    return new OkObjectResult("Success");
                }                
            }
            catch (Exception ex)
            {
                _logger.LogError($"PlagiarismCheckForMultipleFileAssessment: {ex.Message}");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
            _logger.LogInformation("End PlagiarismCheckForMultipleFileAssessment");
            return new NoContentResult();
        }
    }
}
